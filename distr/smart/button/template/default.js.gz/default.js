import {html, nothing} from 'lit';
import {createInlineSpinner} from '../../../../component/spinner/js/_spinner-draw';


export function renderButtonTemplate(context) {
    const {
        size,
        appearance,
        type,
        scheme,
        status,
        text,
        icon,
        iconLeft,
        iconRight,
        iconPosition,
        spacing,
        radius,
        rootClass,
        textPosition,
        loading,
        disabled,
        nativeType,
        ariaLabel,
        segment,
    } = context;

    const normalizedIconPosition = String(iconPosition || 'start').toLowerCase();
    const isIconEnd = ['right', 'end'].includes(normalizedIconPosition);
    const leftIconName = context.cycleView?.icon || (context.iconStart ?? (iconLeft || (icon && !isIconEnd ? icon : '')));
    const rightIconName = context.menuArrow || (context.iconEnd ?? (iconRight || (icon && isIconEnd ? icon : '')));
    const component = context.component;
    const leftIconContent =
        component?.hasSlotContent?.('icon-start')
            ? component.getSlotContent('icon-start')
            : component?.hasSlotContent?.('icon-left')
            ? component.getSlotContent('icon-left')
            : component.createIcon(leftIconName, context.pressed === true || Boolean(context.cycleView?.pressedLook));
    const rightIconContent =
        component?.hasSlotContent?.('icon-end')
            ? component.getSlotContent('icon-end')
            : component?.hasSlotContent?.('icon-right')
            ? component.getSlotContent('icon-right')
            : component.createIcon(rightIconName, context.pressed === true);
    // A toggle whose label changes (text-pressed, 1.6.0): «В избранное» at rest,
    // «В избранном» while on. The label then says the state, so aria-pressed
    // is not written as well (docs review R028, rule C12): a screen reader
    // would hear «В избранном, нажата». The look follows pressed either way.
    const pressedLabel = context.pressed === true && context.textPressed ? context.textPressed : '';
    const announcesPressed = context.pressed !== undefined && !context.textPressed;
    const textContent =
        component?.hasSlotContent?.('text')
            ? component.getSlotContent('text')
            : context.cycleView?.label || pressedLabel || text;
    // The shortcut's keys sit at the end; the label then takes the free room,
    // so a stretched button reads label ... keys and text-position places it.
    // The keys are the kbd component's (soft caps inside a button); the
    // wrapper only gives them the label's ink.
    const shortcutCaps = context.shortcutCaps || [];
    const fullText = (!leftIconContent && !rightIconContent) || shortcutCaps.length > 0;
    // Loading shows the spinner at the icon's size (simai/ui-source#10): in
    // place of the start icon, else of the end icon; a button without an icon
    // lays it over its label, which keeps its place (and the button its width)
    // and stays the accessible name. Icon-only is the first case.
    let startContent = leftIconContent;
    let endContent = rightIconContent;
    let overlayContent = '';
    if (loading) {
        const spinner = (overlay) => createInlineSpinner({className: 'sf-button-spinner', overlay});
        if (leftIconContent) startContent = spinner(false);
        else if (rightIconContent) endContent = spinner(false);
        else overlayContent = spinner(true);
    }
    const rootClasses = [
        'sf-button',
        `sf-button--size-${size}`,
        // ghost (C15): the class is sf-button--ghost; sf-button--link, its
        // former name, is written beside it until 2027-01-01 (journal
        // class-button-link-to-ghost), so a page selector that reached it
        // still does. href, not the look, makes a link.
        `sf-button--${appearance || type}`,
        (appearance || type) === 'ghost' ? 'sf-button--link' : '',
        // One colour name, as the styles expect: the status when one is set, the
        // scheme otherwise. A status says what the control is about -- an error
        // for something destructive -- and a scheme says which colour family it
        // takes; they cannot both paint it.
        // danger (C13) is drawn with the error roles: the danger class and the
        // error one the sheets and their consumers also select.
        ...(status === 'danger' || status === 'error' ? ['sf-button--danger', 'sf-button--error'] : [`sf-button--${scheme}`]),
        // on-surface-variant is the on-surface family one step quieter: both
        // classes, so every on-surface rule holds and one rule quietens it.
        !status && scheme === 'on-surface-variant' ? 'sf-button--on-surface' : '',
        'flex',
        'items-cross-center',
        segment ? `segment-${segment}` : '',
        // The spacing class, not its retired tightness name (journal
        // class-tightness-to-spacing; docs trial 4).
        spacing && spacing !== 'normal' ? `spacing-${spacing}` : '',
        // The height (decision C27): the class of the size's tightness step;
        // default draws none, the size's own step.
        context.height && context.height !== 'default' ? `sf-button--height-${context.height}` : '',
        radius ? `radius-${radius}` : '',
        // full-width (1.12.0, owner decision C36): sf-segmented's setting.
        context.fullWidth ? 'sf-button--full-width' : '',
        // overflow="truncate" (1.17.0, FW-LH-1, owner decision C301 (2)): one
        // line, cut with an ellipsis at max-width or the container's width.
        context.overflow === 'truncate' ? 'sf-button--truncate' : '',
        rootClass,
        loading ? 'loading sf-button-state-loading' : '',
        // A loading button keeps its scheme colour (owner decision C36); one
        // that is disabled as well wears the disabled look, so it says so.
        loading && disabled ? 'disabled' : '',
        // A toggle that is on wears the pressed look (component.buttons 1.5.0,
        // rule C12): the class carries it whether or not aria-pressed is said.
        context.pressed || context.cycleView?.pressedLook ? 'sf-button--pressed' : '',
    ].filter(Boolean);

    const content = html`
            ${overlayContent}
            ${startContent}
            ${textContent ? html`<span
                    class="sf-button-text-container text-${textPosition} pointer-events-none${fullText ? ' flex-1' : ''}">
        ${textContent}
      </span>` : ''}
            ${endContent}${renderCutTooltip(context)}${shortcutCaps.length ? html`<span class="sf-button-shortcut pointer-events-none" aria-hidden="true"><kbd class="sf-kbd--group">${shortcutCaps.map((cap, at) => html`${at && context.shortcutJoin ? html`<span class="sf-kbd-join">+</span>` : nothing}<kbd class=${cap.square ? 'sf-kbd--square' : nothing}>${cap.text}</kbd>`)}</kbd></span>` : ''}
`;

    // href (1.4.0): a link with the button's look. The browser's own link
    // follows it (Enter, the context menu, a new tab); a button's states that
    // a link has no words for -- native-type, expanded, pressed -- do not
    // apply. Disabled or loading, the link has no href, so it is not reached
    // or followed, and says aria-disabled.
    if (context.href) {
        const inactive = Boolean(disabled || loading);
        return html`
        <a
                href=${inactive ? nothing : context.href}
                target=${context.linkTarget || nothing}
                rel=${context.linkRel || nothing}
                class=${rootClasses.join(' ')}
                style=${context.rootStyle || nothing}
                role=${inactive ? 'link' : nothing}
                aria-disabled=${inactive ? 'true' : nothing}
                aria-label=${ariaLabel || nothing}
                aria-busy=${loading ? 'true' : nothing}
                aria-keyshortcuts=${context.ariaKeyShortcuts || nothing}
                data-tooltip=${context.cutTooltipId || nothing}
        >${content}</a>
    `;
    }

    const button = html`
        <button
                type=${nativeType}
                form=${context.formId || nothing}
                name=${context.submitName || nothing}
                value=${context.submitName || context.submitValue ? context.submitValue : nothing}
                class=${rootClasses.join(' ')}
                style=${context.rootStyle || nothing}
                ?disabled=${disabled || loading}
                aria-label=${ariaLabel || nothing}
                aria-busy=${loading ? 'true' : nothing}
                aria-expanded=${context.expanded === undefined ? nothing : String(Boolean(context.expanded))}
                aria-haspopup=${context.hasPopup || nothing}
                @keydown=${context.menuMode === 'menu' ? (event) => component.onMenuKey(event) : nothing}
                aria-pressed=${announcesPressed ? String(Boolean(context.pressed)) : nothing}
                aria-keyshortcuts=${context.ariaKeyShortcuts || nothing}
                data-tooltip=${context.cutTooltipId || nothing}
        >${content}</button>${context.cycleView ? html`<span class="sf-button-announce sr-only" role="status" aria-live="polite" aria-atomic="true">${context.cycleView.announcement}</span>` : nothing}
    `;

    if (!context.menuMode) return button;
    return html`${context.menuMode === 'split' ? renderSplit(context, button) : button}${renderMenu(context)}`;
}

// The Framework's plain tooltip (component.tooltip, class markup) of a label
// cut with an ellipsis (overflow="truncate", FW-LH-1, C301 (2)), as sf-tag's
// (C58): hidden until the tooltip controller shows it on hover or keyboard
// focus. The label stays whole in the markup, so the accessible name is all of
// it; the tooltip is for the eye and says the whole label (or the host's title).
function renderCutTooltip(context) {
    if (!context.cutTooltipId) return nothing;
    return html`<span id=${context.cutTooltipId} class="sf-tooltip sf-tooltip--dark sf-tooltip--size-1/3 sf-button-tooltip" aria-hidden="true" hidden><span class="sf-tooltip-content"><span class="sf-tooltip-text">${context.cutText}</span></span></span>`;
}

const stop = (event) => event.stopPropagation();

// The split button (1.15.0, owner decision C119): the label part is the button
// above; the arrow part is an sf-button-icon of the same size, height, look and
// radius -- square, so it is as tall as the label part on every size, height
// and density -- with expand_more. The buttons sheet joins them like a button
// group (sf-button-split): inner corners square, a 1 px seam (the page between
// two filled parts, one shared border between two outlined ones). Its press
// opens the menu and stays inside: the page hears sf-button-press from the
// label part and sf-button-select from the menu.
function renderSplit(context, button) {
    const {component} = context;
    const off = Boolean(context.disabled || context.loading);
    return html`<span class=${['sf-button-split', context.fullWidth ? 'sf-button-split--full-width' : ''].filter(Boolean).join(' ')}>${button}<sf-button-icon
            class="sf-button-split-arrow"
            icon="expand_more"
            appearance=${context.appearance}
            scheme=${context.scheme}
            size=${context.size}
            height=${context.height && context.height !== 'default' ? context.height : nothing}
            radius=${context.radius || nothing}
            ?disabled=${off}
            aria-label=${context.splitLabel}
            title=${context.splitLabel}
            aria-haspopup="menu"
            aria-expanded="false"
            @click=${() => component.toggleMenu()}
            @keydown=${(event) => component.onMenuKey(event)}
            @sf-button-icon-press=${stop}
        ></sf-button-icon></span>`;
}

// The menu is the Framework's sf-menu-context, a popup opened under the
// control (end-aligned under a split button's arrow). Its own events stay
// inside: the page hears sf-button-select.
function renderMenu(context) {
    const {component} = context;
    return html`<sf-menu-context
            popup
            size=${context.size === '1/3' || context.size === '1/2' ? '1/2' : '1'}
            aria-label=${context.text || context.ariaLabel || nothing}
            .entries=${context.menuEntries}
            @sf-menu-context-select=${(event) => component.onMenuSelect(event)}
            @sf-context-menu-select=${stop}
        ></sf-menu-context>`;
}
