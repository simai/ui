import {html, nothing} from 'lit';

// Framework utilities and the header's own sheet (scss/: the gaps and colours
// are its public variables): a column for the path above the line, and a line
// holding the title -- the heading, its count, the install mark and the star --
// then the actions at the end. The heading is the fourth heading step, the size
// the admin pages have always titled themselves at. The title is a group of its
// own so that a long heading closes down to its ellipsis beside the actions
// instead of taking a line and pushing the count and the actions under it
// (HD-12); the count and the marks stay right after the words. The actions
// come in the header's order, the main one last (C161 (3)); the tabs slot
// ends the header, its line the header's lower edge (C161 (5)).
export function renderPageHeaderTemplate(context) {
  const {component, heading, count, level, star, text, hostSlot, hasHostSlot, rootClass} = context;
  const classes = ['sf-page-header', 'flex', 'flex-col', 'min-w-0', context.expressive ? 'sf-page-header--expressive' : '', context.sticky ? 'sf-page-header--sticky' : '', rootClass].filter(Boolean).join(' ');
  const on = star === true;
  const actions = context.actions ? context.actions() : {rest: hostSlot('actions'), main: nothing};
  return html`<header class=${classes} style=${context.rootStyle || nothing}>
    ${hasHostSlot('path') ? html`<div class="sf-page-header-path flex items-cross-center min-w-0">${hostSlot('path')}</div>` : nothing}
    <div class="sf-page-header-line flex items-cross-center flex-wrap min-w-0">
      ${hasHostSlot('start') ? hostSlot('start') : nothing}
      <div class="sf-page-header-title flex items-cross-center min-w-0">
        <h1 class="sf-page-header-heading sf-h-4 m-0 min-w-0 truncate">${heading}</h1>
        ${count !== '' && count !== null && count !== undefined
          ? html`<sf-badge appearance="tonal" scheme="neutral" size="1/2" text=${String(count)}></sf-badge>`
          : nothing}
        ${level === 'install'
          ? html`<sf-badge appearance="outline" scheme="tertiary" size="1/2" text=${text('all-sites')}></sf-badge>`
          : nothing}
        ${star === true || star === false
          // The star's name says what pressing it does («В избранное», «Убрать
          // из избранного»), so it says the state too and carries no
          // aria-pressed (1.2.2, rule C12): both at once read «Убрать из
          // избранного, нажата». The filled glyph in its own colour shows it.
          // It stands on its row's rung (C103, 1.7.0): the actions' size while
          // they keep the line beside it, else the start control's, else the
          // half step (index.js syncStarRung).
          ? html`<sf-button-icon size=${context.starSize || '1/2'} appearance="ghost" scheme="on-surface"
              class=${on ? 'sf-page-header-star sf-page-header-star--on' : 'sf-page-header-star'}
              icon="star"
              ?filled=${on}
              aria-label=${on ? text('unstar') : text('star')}
              title=${on ? text('unstar') : text('star')}
              @click=${() => component.toggleStar()}></sf-button-icon>`
          : nothing}
      </div>
      ${hasHostSlot('actions')
        // overflow more (owner decision C155 (7), C161 (3), (4)): one row,
        // and ⋯ for what does not fit, right before the main action, which
        // ends the line -- the actions' rung and the look of the actions it
        // stands for (outlined beside outlined ones, else the quiet ghost),
        // «Ещё» its name and tooltip. It is drawn out of the row
        // (sf-page-header-out) until the row is laid out and something left.
        ? html`<div class=${context.overflow === 'more' ? 'sf-page-header-actions sf-page-header-actions--more flex items-cross-center' : 'sf-page-header-actions flex items-cross-center'}>${actions.rest}${context.overflow === 'more'
            ? html`<sf-button-icon class="sf-page-header-more sf-page-header-out" icon="more_horiz" appearance=${context.moreLook.appearance} scheme=${context.moreLook.scheme || nothing}
                size=${context.moreSize || '1'} aria-label=${text('more')} title=${text('more')} aria-haspopup="menu"
                @click=${(event) => component.openActionsMore(event)}></sf-button-icon>`
            : nothing}${actions.main}</div>`
        : nothing}
    </div>
    ${hasHostSlot('tabs') ? html`<div class="sf-page-header-tabs min-w-0">${hostSlot('tabs')}</div>` : nothing}
  </header>`;
}
