/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "524cdaa09638"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CLOSING_ATTRIBUTE: () => (/* binding */ CLOSING_ATTRIBUTE),
/* harmony export */   markClosing: () => (/* binding */ markClosing),
/* harmony export */   moveSection: () => (/* binding */ moveSection),
/* harmony export */   sectionClock: () => (/* binding */ sectionClock),
/* harmony export */   sectionHeight: () => (/* binding */ sectionHeight),
/* harmony export */   stopSectionMotion: () => (/* binding */ stopSectionMotion)
/* harmony export */ });
// The height motion of an accordion section (owner decision C154 (4)): the
// section grows or shrinks to its new height on the clock of the toggle and
// the check box (C66, C121) -- 200 ms, --sf-ease-move -- and its marker
// turns on the same clock. The clock is the class sheet's: the section's
// transition on block-size, which nothing else animates, so a page that
// changes --sf-accordion--duration or asks for reduced motion (the sheet
// sets it to none) changes the motion here too. Shared by the class runtime
// and sf-accordion; stateless, so each bundle may carry its own copy.
const running = new WeakMap(); // The mark of a section that shrinks to its header: its closed panel stays
// drawn (the class sheet), so the text leaves with the motion.

const CLOSING_ATTRIBUTE = 'data-sf-accordion-closing'; // Panels made inert here, so only those are given back.

const madeInert = new WeakSet(); // Marks a section closing or not. A closing panel is drawn but closed: from
// the start of the close nothing in it takes focus, Tab or a click (inert),
// as after the motion, when the sheet no longer draws it; it is given back
// when the motion ends or the section opens again.

function markClosing(section, closing) {
  if (!section) return;
  if (closing) section.setAttribute(CLOSING_ATTRIBUTE, '');else section.removeAttribute(CLOSING_ATTRIBUTE);
  const panel = Array.from(section.children ?? []).find(child => child.classList?.contains('sf-accordion-content'));
  if (!panel) return;

  if (closing) {
    if (panel.hasAttribute('inert')) return;
    panel.setAttribute('inert', '');
    madeInert.add(panel);
  } else if (madeInert.has(panel)) {
    madeInert.delete(panel);
    panel.removeAttribute('inert');
  }
}

function seconds(value) {
  const first = String(value || '').split(',')[0].trim();
  if (!first) return 0;
  const number = parseFloat(first);
  if (!Number.isFinite(number)) return 0;
  return first.endsWith('ms') ? number : number * 1000;
} // The section's clock: [duration in ms, easing], or null when it does not
// move -- reduced motion, a zero duration, or no layout (a hidden page).


function sectionClock(section) {
  if (!section || typeof getComputedStyle !== 'function' || typeof section.animate !== 'function') return null;
  if (globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return null;
  const style = getComputedStyle(section);
  const properties = String(style.transitionProperty || '').split(',').map(one => one.trim());
  const at = properties.findIndex(one => one === 'block-size' || one === 'height' || one === 'all');
  if (at < 0) return null;
  const durations = String(style.transitionDuration || '').split(',');
  const easings = String(style.transitionTimingFunction || '').split(/,(?![^(]*\))/u);
  const duration = seconds(durations[at] ?? durations[0]);
  if (!(duration > 0)) return null;
  return [duration, (easings[at] ?? easings[0] ?? 'ease').trim()];
} // The height the section stands at now, mid-motion included.

function sectionHeight(section) {
  return section?.getBoundingClientRect?.().height ?? 0;
} // Stops a motion still running on the section (a second press before the
// first ended): the next one starts from where this one stood.

function stopSectionMotion(section) {
  const animation = running.get(section);
  if (!animation) return;
  running.delete(section);
  animation.onfinish = null;
  animation.cancel();
} // Moves the section from the height it stood at to the one it stands at now.
// `done` runs when the motion ends (not when a newer one replaces it); it is
// how a closing section keeps its content in view until it has shrunk.
// Answers whether anything moves; without motion `done` runs at once.

function moveSection(section, from, done) {
  const clock = sectionClock(section);
  const to = sectionHeight(section);

  if (!clock || !(from >= 0) || Math.abs(to - from) < 1) {
    done?.();
    return false;
  }

  const [duration, easing] = clock;
  const animation = section.animate({
    blockSize: [`${from}px`, `${to}px`]
  }, {
    duration,
    easing
  });
  running.set(section, animation);

  animation.onfinish = () => {
    if (running.get(section) === animation) running.delete(section);
    done?.();
  };

  return true;
}

/***/ },

/***/ "0eb897441700"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SfSmartAccordion: () => (/* binding */ SfSmartAccordion)
/* harmony export */ });
/* harmony import */ var _core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("deb1a4d61565");
/* harmony import */ var _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5b7d7695b41b");
/* harmony import */ var _core_js_instance_path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e92fd2d1a38c");
/* harmony import */ var _js_templates_default__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0f6c0abdc39e");
/* harmony import */ var _component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("524cdaa09638");
/* harmony import */ var _sections_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("bb3926f81811");
/* harmony import */ var _scss_index_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("c8becad87ee8");
/* harmony import */ var _component_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("f733ebfdf5a9");
/* harmony import */ var _aliases_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("7b406578f80a");
/* harmony import */ var _lang_index_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("5b5bf2dab10e");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__, _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__, _core_js_instance_path__WEBPACK_IMPORTED_MODULE_2__, _js_templates_default__WEBPACK_IMPORTED_MODULE_3__]);
([_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__, _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__, _core_js_instance_path__WEBPACK_IMPORTED_MODULE_2__, _js_templates_default__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* harmony import */ var _core_js_smart_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_instance_path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_instance_path__WEBPACK_IMPORTED_MODULE_2__);
// sf-accordion: sections built from data -- a record's groups, a settings
// panel, an FAQ -- drawn as the class accordion (src/component/accordion), so
// its styles apply and nothing of them is forked (owner, 2026-10-25). The
// sections come from `items` (an array, or the same as JSON) or from <details>
// written inside the element; a section's markup can come from a slot.
//
// The element draws the class markup and keeps its state itself: open
// sections, single mode, the single section that is a plain section. Each
// section it draws carries data-sf-accordion-init, the class runtime's own
// mark of a section already set up, so that runtime -- loaded beside it for
// the sheet -- leaves the element's sections alone and two owners never toggle
// one section.









 // Only the words on screen ship in the bundle, English only (owner decision
// C282): Russian and every other language come from a language file. The
// title, settings and events stay in the language files for the Studio and the
// docs (localization study LC-2).
// From its component.json (standard simai.smart-component 1.3.8 §3, §4, §8):
// the settings are attributes and properties made by
// core/js/element-manifest.js, open, close and toggle answer outcomes, and the
// old event name sf-accordion:toggle is a dated alias of sf-accordion-toggle.

const AccordionElement = (0,_core_js_element_manifest__WEBPACK_IMPORTED_MODULE_1__.elementFromManifest)(_component_json__WEBPACK_IMPORTED_MODULE_7__, {
  base: (_core_js_smart_base__WEBPACK_IMPORTED_MODULE_0___default()),
  lang: _lang_index_mjs__WEBPACK_IMPORTED_MODULE_9__.files,
  source: 'ru',
  aliases: _aliases_json__WEBPACK_IMPORTED_MODULE_8__
});
const HEADING_LEVELS = ['2', '3', '4', '5', '6']; // open('main') and open({id: 'main'}) both name a section (§4.4).

const sectionArgument = value => value && typeof value === 'object' ? value.id : value; // A closing section's panel stays drawn while it shrinks, inert (markClosing,
// component/accordion/js/motion.js).
// The section the address names (C154 (5)): the fragment, without its #.


function addressId() {
  const hash = globalThis.location?.hash || '';
  if (hash.length < 2) return '';

  try {
    return decodeURIComponent(hash.slice(1));
  } catch {
    return hash.slice(1);
  }
}

class SfSmartAccordion extends AccordionElement {
  static get props() {
    return { ...super.props,
      templateName: {
        attribute: 'template',
        default: 'default'
      },
      items: {
        default: []
      },
      single: {
        type: Boolean,
        default: false
      },
      size: {
        default: '',
        values: _sections_mjs__WEBPACK_IMPORTED_MODULE_5__.ACCORDION_SIZES
      },
      // Lines by default (owner decision C154 (2)).
      appearance: {
        default: _sections_mjs__WEBPACK_IMPORTED_MODULE_5__.ACCORDION_DEFAULT_APPEARANCE,
        values: _sections_mjs__WEBPACK_IMPORTED_MODULE_5__.ACCORDION_APPEARANCES
      },
      marker: {
        default: 'chevron',
        values: _sections_mjs__WEBPACK_IMPORTED_MODULE_5__.ACCORDION_MARKERS
      },
      // One section is a plain section (simai/ui-source#19, #29); `toggle`
      // keeps it a disclosure -- a list that fills in later.
      singleSection: {
        attribute: 'single-section',
        default: 'static',
        values: ['static', 'toggle']
      },
      headingLevel: {
        attribute: 'heading-level',
        default: '3',
        values: HEADING_LEVELS
      },
      // A section's id is its address (C154 (5)).
      link: {
        type: Boolean,
        default: false
      },
      // «Развернуть все / Свернуть все» over five sections or more (C154 (7)).
      expandAll: {
        attribute: 'expand-all',
        type: Boolean,
        default: false
      },
      rootClass: {
        default: ''
      }
    };
  }

  constructor() {
    super(); // undefined: follow the attribute. Set by the property; an attribute
    // written later takes over again.

    this._items = undefined; // What the person or the host opened and closed, by section id, over the
    // open flag each section carries.

    this._openState = new Map();
    this._childSections = []; // Heights the changed sections stood at before a drawing, by id: the
    // drawing moves them from there (C154 (4)).

    this._moving = null; // The address is read after the first drawing, then on each hashchange.

    this._addressPending = true;
    this._scrollTo = ''; // A value set as a property before the element was defined -- a lit
    // `.items` binding on a tag the loader had not upgraded yet -- is an own
    // property that would hide the accessor; it is taken through it.

    if (Object.prototype.hasOwnProperty.call(this, 'items')) {
      const early = this.items;
      delete this.items;
      this._items = (0,_sections_mjs__WEBPACK_IMPORTED_MODULE_5__.normaliseSections)(early);
    }

    this.addEventListener('click', this.onClick);
    this.addEventListener('keydown', this.onKeydown); // Find-in-page found text in a closed panel (C154 (6)).

    this.addEventListener('beforematch', this.onBeforeMatch, true);
  }

  connectedCallback() {
    super.connectedCallback();
    globalThis.addEventListener?.('hashchange', this.onHashChange);
  }

  disconnectedCallback() {
    globalThis.removeEventListener?.('hashchange', this.onHashChange);
    super.disconnectedCallback?.();
  }

  attributeChangedCallback(name, previous, next) {
    if (name === 'items' && previous !== next) this._items = undefined;
    super.attributeChangedCallback(name, previous, next);
  } // The <details> written inside the element are sections too: the summary
  // is the title, everything else the content, which stays the same live
  // nodes. Read once, as slots are, and taken out of the light DOM.


  captureSlotTemplates() {
    const first = !this._slotTemplatesCaptured;
    super.captureSlotTemplates();
    if (!first) return;
    Array.from(this.children).filter(child => child.localName === 'details').forEach((details, index) => {
      const summary = details.querySelector(':scope > summary');
      const section = (0,_sections_mjs__WEBPACK_IMPORTED_MODULE_5__.normaliseSection)({
        id: details.dataset.id || details.id,
        title: summary?.textContent.replace(/\s+/gu, ' ').trim() || '',
        open: details.open,
        disabled: details.hasAttribute('data-disabled'),
        icon: details.dataset.icon,
        badge: details.dataset.badge,
        summary: details.dataset.summary
      }, index); // A local name: the slot map is the element's own (§7.1.1, #41).

      section.slot = `sf-accordion-child-${index}`;
      const nodes = Array.from(details.childNodes).filter(node => node !== summary);
      if (nodes.length) this._liveSlotNodes.set(section.slot, nodes);

      this._childSections.push(section);

      details.remove();
    });
  } // The sections, from the property or the attribute, else from the markup.


  get items() {
    if (this._items !== undefined) return this._items;
    return (0,_sections_mjs__WEBPACK_IMPORTED_MODULE_5__.normaliseSections)(this.getAttribute('items'));
  }

  set items(next) {
    this._items = (0,_sections_mjs__WEBPACK_IMPORTED_MODULE_5__.normaliseSections)(next);
    this.requestComponentUpdate('items');
  }

  get sections() {
    const items = this.items;
    return items.length ? items : this._childSections;
  } // single, size, appearance, marker and heading-level are the manifest's
  // accessors (attribute and property); expanded is the open ids (§4 values).


  get expanded() {
    return this.openIds;
  } // An accordion inside a section draws lines, whatever its appearance
  // (C154 (8)); the class sheet holds the same for class markup.


  get drawnAppearance() {
    if (this.parentElement?.closest?.('.sf-accordion-content')) return 'flush';
    return this.appearance || _sections_mjs__WEBPACK_IMPORTED_MODULE_5__.ACCORDION_DEFAULT_APPEARANCE;
  } // The one section that stands alone is a plain section: no toggle.


  get isStatic() {
    return this.sections.length === 1 && this.getProp('singleSection') !== 'toggle';
  } // The ids of the open sections, in order. A single section is always open.


  get openIds() {
    const sections = this.sections;
    if (this.isStatic) return sections.map(section => section.id);
    return [...(0,_sections_mjs__WEBPACK_IMPORTED_MODULE_5__.openSections)(sections, this._openState, this.single)];
  }

  isOpen(id) {
    return this.openIds.includes(String(id));
  }

  section(id) {
    return this.sections.find(section => section.id === String(id)) || null;
  } // The actions open, close and toggle {id} (§4.4): each answers an outcome.


  open(id) {
    return this.setOpen(sectionArgument(id), true, 'method');
  }

  close(id) {
    return this.setOpen(sectionArgument(id), false, 'method');
  }

  toggle(id) {
    const key = sectionArgument(id);
    return this.setOpen(key, !this.isOpen(key), 'method');
  } // Opens or closes one section. In single mode opening one closes the one
  // that was open, and each change is reported, as a native <details name>
  // group reports the one it closes. A disabled section, a section that is
  // already so, and the single section do nothing. Answers an outcome:
  // applied, or refused with unknown, static, disabled or already.
  // The sections move to their new height (C154 (4)) unless motion is false:
  // the browser's find shows the text at once, an address opens in place.


  setOpen(id, open, source = 'method', {
    motion = true
  } = {}) {
    const section = this.section(id);
    if (!section) return {
      outcome: 'refused',
      reason: 'unknown'
    };
    if (this.isStatic) return {
      outcome: 'refused',
      reason: 'static'
    };
    if (section.disabled && source === 'user') return {
      outcome: 'refused',
      reason: 'disabled'
    };
    const before = new Set(this.openIds);
    if (before.has(section.id) === Boolean(open)) return {
      outcome: 'refused',
      reason: 'already'
    };

    if (open && this.single) {
      for (const other of before) this._openState.set(other, false);
    }

    this._openState.set(section.id, Boolean(open));

    this.commitOpen(before, source, motion, section.id);
    return {
      outcome: 'applied'
    };
  } // «Развернуть все» opens every section that can open, «Свернуть все» closes
  // them, when all are open (C154 (7)). A disabled section stays as it is.


  toggleAll(source = 'user') {
    if (this.isStatic || this.single) return {
      outcome: 'refused',
      reason: this.isStatic ? 'static' : 'single'
    };
    const enabled = this.sections.filter(one => !one.disabled);
    const open = !enabled.every(one => this.isOpen(one.id));
    const before = new Set(this.openIds);
    enabled.forEach(one => this._openState.set(one.id, open));
    this.commitOpen(before, source, true, '');
    return {
      outcome: 'applied'
    };
  } // After a change of the open sections: the drawing, the motion of each
  // section that changed and its event, the one asked for first.


  commitOpen(before, source, motion, first) {
    const after = new Set(this.openIds);
    const changed = this.sections.filter(one => before.has(one.id) !== after.has(one.id));

    if (motion) {
      this._moving = this._moving || new Map();

      for (const one of changed) {
        const article = this.sectionElement(one.id);
        if (article && !this._moving.has(one.id)) this._moving.set(one.id, (0,_component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__.sectionHeight)(article));
      }
    }

    this.requestComponentUpdate('open'); // The section asked for first, then the one single mode closed.

    changed.sort((a, b) => a.id === first ? -1 : b.id === first ? 1 : 0); // sf-accordion-toggle, then its old name sf-accordion:toggle with the same
    // detail (aliases.json, until 2026-12-01).

    for (const one of changed) {
      this.sfEmit('toggle', {
        id: one.id,
        open: after.has(one.id),
        source,
        section: one
      });
    }
  } // The drawn section of this element (not of an accordion nested in it).


  sectionElement(id) {
    return Array.from(this.querySelectorAll('article.sf-accordion[data-sf-accordion-id]')).find(article => article.dataset.sfAccordionId === String(id) && article.closest('sf-accordion') === this) || null;
  } // The drawing is in: each section that changed moves from the height it
  // stood at to its new one; a closing one keeps its panel drawn until then.


  renderTemplateResult(templateResult) {
    const result = super.renderTemplateResult(templateResult);
    const moving = this._moving;
    this._moving = null;
    moving?.forEach((from, id) => {
      const article = this.sectionElement(id);
      if (!article) return;
      (0,_component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__.stopSectionMotion)(article);
      (0,_component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__.markClosing)(article, false);
      const moved = (0,_component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__.moveSection)(article, from, () => (0,_component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__.markClosing)(article, false));
      if (moved && !this.isOpen(id)) (0,_component_accordion_js_motion_js__WEBPACK_IMPORTED_MODULE_4__.markClosing)(article, true);
    });
    return result;
  }

  afterRender(changed) {
    const result = super.afterRender(changed);
    if (typeof changed !== 'function') this.followAddress();
    return result;
  } // With link (C154 (5)): the section the address names opens, in place, and
  // the page scrolls to it; read after the first drawing and on hashchange.


  followAddress() {
    if (this._addressPending) {
      this._addressPending = false;
      const id = addressId();

      if (this.link && id && this.section(id)) {
        if (!this.isOpen(id)) this.setOpen(id, true, 'method', {
          motion: false
        });
        this._scrollTo = id;
      }
    }

    if (!this._scrollTo || this._moving) return;
    const article = this.sectionElement(this._scrollTo);
    if (!article || !this.isOpen(this._scrollTo) && !this.isStatic) return;
    this._scrollTo = '';
    article.scrollIntoView?.({
      block: 'start'
    });
    article.querySelector('.sf-accordion-trigger')?.focus?.({
      preventScroll: true
    });
  }

  onHashChange = () => {
    this._addressPending = true;
    this.followAddress();
  }; // The browser found the text in a closed panel and shows it (C154 (6)):
  // the section opens as a press would, without motion.

  onBeforeMatch = event => {
    const article = event.target?.closest?.('article.sf-accordion[data-sf-accordion-id]');
    if (!article || article.closest('sf-accordion') !== this) return;
    const id = article.dataset.sfAccordionId;
    if (!this.isOpen(id)) this.setOpen(id, true, 'user', {
      motion: false
    });
  }; // The header buttons of this element, not of an accordion nested inside it.

  triggers() {
    return Array.from(this.querySelectorAll('.sf-accordion-trigger[data-sf-accordion-section]')).filter(trigger => trigger.closest('sf-accordion') === this && trigger.localName === 'button');
  }

  ownTrigger(target) {
    const trigger = target?.closest?.('button.sf-accordion-trigger[data-sf-accordion-section]');
    return trigger && trigger.closest('sf-accordion') === this ? trigger : null;
  }

  focusDelegate() {
    return this.triggers().find(trigger => !trigger.disabled) || null;
  }

  onClick = event => {
    const all = event.target?.closest?.('.sf-accordion-all-button');

    if (all && all.closest('sf-accordion') === this) {
      this.toggleAll('user');
      return;
    }

    const trigger = this.ownTrigger(event.target);
    if (!trigger || trigger.disabled) return;
    const id = trigger.dataset.sfAccordionSection;
    const result = this.setOpen(id, !this.isOpen(id), 'user'); // With link, opening writes the section's address, without a new entry
    // in the history (C154 (5)).

    if (this.link && result.outcome === 'applied' && this.isOpen(id)) {
      try {
        const url = new URL(globalThis.location.href);
        url.hash = id;
        globalThis.history?.replaceState?.(globalThis.history.state, '', url);
      } catch {// An address the page cannot write (a sandboxed frame) is left as it is.
      }
    }
  }; // Enter and Space are the button's own. The arrows walk the headers, Home
  // and End go to the first and the last (WAI-ARIA accordion pattern); a
  // disabled header is passed over, as it takes no focus.

  onKeydown = event => {
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    const trigger = this.ownTrigger(event.target);
    if (!trigger || event.target !== trigger) return;
    if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
    const triggers = this.triggers().filter(one => !one.disabled);
    if (!triggers.length) return;
    const at = triggers.indexOf(trigger);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? triggers.length - 1 : (at + (event.key === 'ArrowDown' ? 1 : -1) + triggers.length) % triggers.length;
    event.preventDefault();
    triggers[next].focus();
  };

  templateContext() {
    const props = this.getPropsContext();
    const sections = this.sections;
    const open = new Set(this.openIds);
    return this.createTemplateContext({ ...props,
      component: this,
      // The host's path id (§7.1.1, simai/ui-source#41): the header and panel
      // ids are <path>--trigger-<n> and <path>--panel-<n>.
      id: (0,_core_js_instance_path__WEBPACK_IMPORTED_MODULE_2__.partId)((0,_core_js_instance_path__WEBPACK_IMPORTED_MODULE_2__.instancePath)(this, {
        kind: 'sf-accordion'
      })),
      sections,
      open,
      single: this.single,
      isStatic: this.isStatic,
      size: this.size,
      appearance: this.drawnAppearance,
      link: Boolean(this.link),
      expandAllShown: (0,_sections_mjs__WEBPACK_IMPORTED_MODULE_5__.showsExpandAll)(sections, {
        expandAll: this.expandAll,
        single: this.single,
        isStatic: this.isStatic
      }),
      allOpen: sections.filter(one => !one.disabled).every(one => open.has(one.id)),
      expandAllText: this.sfWord('expandAll'),
      collapseAllText: this.sfWord('collapseAll'),
      marker: this.marker,
      // The enum of the class sheet's levels; the property is the number.
      headingLevel: this.getProp('headingLevel'),
      rootClass: this.getRootClass()
    });
  }

  template() {
    return (0,_js_templates_default__WEBPACK_IMPORTED_MODULE_3__.renderAccordionTemplate)(this.templateContext());
  }

}

SfSmartAccordion.define('sf-accordion');

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "0f6c0abdc39e"
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   renderAccordionTemplate: () => (/* binding */ renderAccordionTemplate)
/* harmony export */ });
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2a080a730149");
/* harmony import */ var lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("efa66f8927d1");
/* harmony import */ var _sections_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("bb3926f81811");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lit__WEBPACK_IMPORTED_MODULE_0__, lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_1__]);
([lit__WEBPACK_IMPORTED_MODULE_0__, lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* harmony import */ var lit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_1__);




function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(' ');
} // The class accordion's own classes: the size on the ladder, the appearance,
// the marker, and the states its runtime writes (active, static).


function sectionClasses(context, section, open) {
  return joinClasses('sf-accordion', context.size ? `sf-accordion--size-${context.size}` : '', context.appearance && context.appearance !== 'default' ? `sf-accordion--${context.appearance}` : '', context.marker === 'plus-minus' ? 'sf-accordion--plus-minus' : '', context.isStatic ? 'sf-accordion--static' : '', section.disabled && !context.isStatic ? 'sf-accordion--disabled' : '', open ? 'active' : '');
} // The content: the host's markup from the slot the section names, else its
// text. Text is never parsed as markup.


function renderContent(context, section) {
  const {
    component
  } = context;
  if (section.slot && component?.hasSlotContent?.(section.slot)) return component.getSlotContent(section.slot);
  return section.content || lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
} // What stands in the header: an icon before the title, the title, a badge
// after it, a short summary at the end (C154 (3)), then the class
// accordion's marker. The badge is tonal, grey (owner decision C140): it took
// sf-badge's former default, the dark grey fill.


function renderHeaderContent(context, section, open) {
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
    ${section.icon ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<i class="sf-icon sf-accordion-lead" aria-hidden="true">${section.icon}</i>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
    <span class="sf-accordion-title">${section.title}</span>
    ${section.badge ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<sf-badge class="sf-accordion-badge" appearance="tonal" size=${_sections_mjs__WEBPACK_IMPORTED_MODULE_2__.BADGE_SIZE[context.size] || '1/3'}
          line=${_sections_mjs__WEBPACK_IMPORTED_MODULE_2__.BADGE_LINE[context.size] || lit__WEBPACK_IMPORTED_MODULE_0__.nothing} text=${section.badge}></sf-badge>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
    ${section.summary ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-accordion-summary">${section.summary}</span>` : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
    ${context.isStatic ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<i class="sf-icon" aria-hidden="true">${(0,_sections_mjs__WEBPACK_IMPORTED_MODULE_2__.markerGlyph)(context.marker, open)}</i>`}
  `;
}

function renderSection(context, section, index) {
  const open = context.open.has(section.id);
  const triggerId = `${context.id}--trigger-${index}`;
  const panelId = `${context.id}--panel-${index}`; // A landmark for each panel only while there are few of them.

  const region = context.sections.length <= _sections_mjs__WEBPACK_IMPORTED_MODULE_2__.REGION_LIMIT; // The single section is a plain section, as the class runtime draws it: a
  // plain element holding the title in the button's place, the content shown.

  const header = context.isStatic ? (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<span class="sf-accordion-trigger" id=${triggerId} data-sf-accordion-static>${renderHeaderContent(context, section, true)}</span>` : (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`<button class="sf-accordion-trigger" type="button" id=${triggerId}
                   data-sf-accordion-section=${section.id}
                   aria-expanded=${open ? 'true' : 'false'} aria-controls=${panelId}
                   ?disabled=${section.disabled}>${renderHeaderContent(context, section, open)}</button>`; // With link the section's id is its address (C154 (5)): #id opens it.

  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
    <article class=${sectionClasses(context, section, open)} id=${context.link ? section.id : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
             data-sf-accordion-init="1" data-sf-accordion-id=${section.id}>
      <div class="sf-accordion-heading" role="heading" aria-level=${context.headingLevel}>${header}</div>
      <div class="sf-accordion-content" id=${panelId}
           role=${region ? 'region' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing} aria-labelledby=${region ? triggerId : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
           hidden=${open ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : 'until-found'}>${renderContent(context, section)}</div>
    </article>
  `;
} // «Развернуть все» over the sections (C154 (7)): a ghost button at the end of
// the row, «Свернуть все» once every section that can open is open.


function renderExpandAll(context) {
  if (!context.expandAllShown) return lit__WEBPACK_IMPORTED_MODULE_0__.nothing;
  const all = context.allOpen;
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
    <div class="sf-accordion-all">
      <sf-button class="sf-accordion-all-button" appearance="ghost" scheme="on-surface"
                 size=${context.size || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
                 icon-start=${all ? 'unfold_less' : 'unfold_more'}
                 text=${all ? context.collapseAllText : context.expandAllText}></sf-button>
    </div>
  `;
} // The sections stand in a column as wide as the element: a flex column, not a
// grid, whose auto track would widen to a long word and push the page
// sideways. Filled and outlined sections stand apart, flush ones meet.


function renderAccordionTemplate(context) {
  const flush = context.appearance === 'flush';
  return (0,lit__WEBPACK_IMPORTED_MODULE_0__.html)`
    ${renderExpandAll(context)}
    <div class=${joinClasses('sf-accordion-group', 'sf-smart-accordion', 'flex', 'flex-col', flush ? '' : 'gap-2', context.rootClass)}
         style=${context.rootStyle || lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
         data-mode=${context.single ? 'single' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}
         data-single-section=${context.isStatic ? lit__WEBPACK_IMPORTED_MODULE_0__.nothing : context.sections.length === 1 ? 'toggle' : lit__WEBPACK_IMPORTED_MODULE_0__.nothing}>
      ${(0,lit_directives_repeat_js__WEBPACK_IMPORTED_MODULE_1__.repeat)(context.sections, section => section.id, (section, index) => renderSection(context, section, index))}
    </div>
  `;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ },

/***/ "c8becad87ee8"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ },

/***/ "5b7d7695b41b"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("element-manifest", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("element-manifest", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "e92fd2d1a38c"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("instance-path", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("instance-path", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "efa66f8927d1"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit/directives/repeat.js", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit/directives/repeat.js", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "2a080a730149"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("lit", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("lit", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "deb1a4d61565"
(module) {

module.exports = (globalThis.SF && globalThis.SF.runtimeModule ? globalThis.SF.runtimeModule("smart-base", 1) : new Promise((resolve, reject) => globalThis.addEventListener("sf-runtime-ready", () => globalThis.SF.runtimeModule("smart-base", 1).then(resolve, reject), { once: true })));

/***/ },

/***/ "5b5bf2dab10e"
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   files: () => (/* binding */ files)
/* harmony export */ });
/* harmony import */ var _en_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("43114319d847");
// Written by scripts/build-language-packs.mjs from src/core/lang/built-in.json
// (owner decision C282); do not edit. The words this bundle carries: the
// built-in languages' (en); every other language comes from
// a language file (core/lang/<code>.js or its parts).


const files = { en: { runtime: _en_json__WEBPACK_IMPORTED_MODULE_0__.runtime } };

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({ en: _en_json__WEBPACK_IMPORTED_MODULE_0__.runtime });


/***/ },

/***/ "bb3926f81811"
(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ACCORDION_APPEARANCES: () => (/* binding */ ACCORDION_APPEARANCES),
/* harmony export */   ACCORDION_DEFAULT_APPEARANCE: () => (/* binding */ ACCORDION_DEFAULT_APPEARANCE),
/* harmony export */   ACCORDION_MARKERS: () => (/* binding */ ACCORDION_MARKERS),
/* harmony export */   ACCORDION_SIZES: () => (/* binding */ ACCORDION_SIZES),
/* harmony export */   BADGE_LINE: () => (/* binding */ BADGE_LINE),
/* harmony export */   BADGE_SIZE: () => (/* binding */ BADGE_SIZE),
/* harmony export */   EXPAND_ALL_FROM: () => (/* binding */ EXPAND_ALL_FROM),
/* harmony export */   REGION_LIMIT: () => (/* binding */ REGION_LIMIT),
/* harmony export */   markerGlyph: () => (/* binding */ markerGlyph),
/* harmony export */   normaliseSection: () => (/* binding */ normaliseSection),
/* harmony export */   normaliseSections: () => (/* binding */ normaliseSections),
/* harmony export */   openSections: () => (/* binding */ openSections),
/* harmony export */   showsExpandAll: () => (/* binding */ showsExpandAll)
/* harmony export */ });
// The parts of sf-accordion that are about data, not the page: the shape a
// section takes, from the items a host gives or from a <details> written in
// the markup, and which sections are open. Kept apart from the element so the
// contract tests can run them in Node, as sf-image-field's value.mjs is.

// The sizes of the class accordion's control ladder; '' keeps its roomy
// default header, the look of a content page.
const ACCORDION_SIZES = Object.freeze(['', '1/3', '1/2', '1', '2', '3']);
// The class accordion's appearances: a filled surface, a hairline border, or
// no fill and no radius with a line between sections. Lines (flush) are the
// default look (owner decision C154 (2)); the filled plates are the value
// `default`, kept by that name.
const ACCORDION_APPEARANCES = Object.freeze(['default', 'outline', 'flush']);
const ACCORDION_DEFAULT_APPEARANCE = 'flush';
// What marks a section open or closed: the class accordion's chevron, or its
// plus and minus.
const ACCORDION_MARKERS = Object.freeze(['chevron', 'plus-minus']);
// More open panels than this, and a landmark for each would crowd the page
// (WAI-ARIA accordion pattern): the panels stop being regions.
const REGION_LIMIT = 6;
// «Развернуть все / Свернуть все» stands over a list of this many sections or
// more (owner decision C154 (7)); a shorter list is read at a glance.
const EXPAND_ALL_FROM = 5;

const text = (value) => (value === null || value === undefined ? '' : String(value));

// An id a section can be named by in open(id), in the events and in an
// element id: the host's own, or its place.
function sectionId(raw, index) {
  const id = text(raw).trim();
  return id || `section-${index + 1}`;
}

// One section, as the element draws it. `content` is text, never markup: the
// host's markup goes in a slot (`slot` names it), so nothing a record holds
// is parsed as HTML.
function normaliseSection(item, index = 0) {
  if (typeof item === 'string') item = {title: item};
  if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
  return {
    id: sectionId(item.id ?? item.key, index),
    title: text(item.title ?? item.label ?? item.text),
    content: text(item.content),
    slot: text(item.slot).trim(),
    open: Boolean(item.open),
    disabled: Boolean(item.disabled),
    icon: text(item.icon).trim(),
    badge: text(item.badge).trim(),
    // A short summary at the end of the header (C154 (3)): «Выбрано 2».
    summary: text(item.summary).trim(),
  };
}

// The sections from what a host gave: an array, or the same array as JSON in
// the `items` attribute. A section whose id repeats an earlier one is left
// out, as one id must name one section.
function normaliseSections(items) {
  let list = items;
  if (typeof list === 'string') {
    const raw = list.trim();
    if (!raw) return [];
    try {
      list = JSON.parse(raw);
    } catch {
      return [];
    }
  }
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const sections = [];
  list.forEach((item, index) => {
    const section = normaliseSection(item, index);
    if (!section || seen.has(section.id)) return;
    seen.add(section.id);
    sections.push(section);
  });
  return sections;
}

// Whether the expand-all button stands over these sections (C154 (7)): the
// setting is on, there are enough of them, and more than one may be open.
function showsExpandAll(sections, {expandAll = false, single = false, isStatic = false} = {}) {
  return Boolean(expandAll) && !single && !isStatic && sections.length >= EXPAND_ALL_FROM;
}

// Which sections are open: what the person or the host set, else what the
// section says. In single mode only the first of them stays open.
function openSections(sections, overrides = new Map(), single = false) {
  const open = new Set();
  for (const section of sections) {
    const state = overrides.has(section.id) ? overrides.get(section.id) : section.open;
    if (!state) continue;
    if (single && open.size) break;
    open.add(section.id);
  }
  return open;
}

// The chevron's glyph, or plus and minus: the words the class accordion's
// runtime writes.
function markerGlyph(marker, open) {
  if (marker === 'plus-minus') return open ? 'remove' : 'add';
  return 'chevron_right';
}

// The badge is a size the header carries: 1/3 up to a size 1 header, then one
// rung below the header (sf-badge has 1/3, 1/2 and 1).
const BADGE_SIZE = Object.freeze({'': '1/3', '1/3': '1/3', '1/2': '1/3', 1: '1/3', 2: '1/2', 3: '1'});

// The badge takes the line of the text beside it at every size (sf-badge
// line="text": the title's size and line, one figure a circle), so the header
// keeps its control height (C01, C18; C95 point 6: a mark beside an item's
// text is as high as its line). A badge size stood taller than the title's
// line wherever the line steps down: at size 1/2 a 1/3 badge (24, phone 20)
// grew the 32 header to 36 (phone 28 to 32); in a compact region the default
// and size 1 headers (14/20 text) took a 24 badge, 48 to 52 and 32 to 36; on a
// phone size 3 (18/24 text) took a 28 badge, 52 to 56 (intent acceptance
// 2026-11-13, content-5). The badge size stays the fallback where line is
// not read.
const BADGE_LINE = Object.freeze({'': 'text', '1/3': 'text', '1/2': 'text', 1: 'text', 2: 'text', 3: 'text'});


/***/ },

/***/ "7b406578f80a"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"$comment":"Dated aliases of sf-accordion for the shim (core/js/aliases.js, standard §16 item 20). mode: same-detail (the shim sends the new and the old name), split (the old detail from the element\'s adapter), host-attribute (no shim).","component":"sf-accordion","since":"2026-10-27","remove_after":"2026-12-01","aliases":[{"from":"sf-accordion:toggle","to":"sf-accordion-toggle","kind":"event","component":"sf-accordion","since":"2026-10-27","remove_after":"2026-12-01","mode":"same-detail","cancelable":false,"section":"§8, §16 item 6","note":"the detail {id, open, source, section} is data only, so both names carry the same object"}]}');

/***/ },

/***/ "f733ebfdf5a9"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"id":"smart.accordion","tag":"sf-accordion","version":"1.2.6","kind":"leaf","settings":{"items":{"type":"list","default":[],"of":{"id":"id","title":"string","content":{"type":"string","optional":true},"slot":{"type":"string","optional":true},"open":{"type":"boolean","optional":true},"disabled":{"type":"boolean","optional":true},"icon":{"type":"icon","optional":true},"badge":{"type":"string","optional":true}}},"single":{"type":"boolean","default":false},"size":{"type":"enum","values":["","1/3","1/2","1","2","3"],"default":""},"appearance":{"type":"enum","values":["default","outline","flush"],"default":"flush"},"marker":{"type":"enum","values":["chevron","plus-minus"],"default":"chevron"},"single-section":{"type":"enum","values":["static","toggle"],"default":"static"},"heading-level":{"type":"number","integer":true,"min":2,"max":6,"default":3},"link":{"type":"boolean","default":false},"expand-all":{"type":"boolean","default":false}},"values":{"expanded":{"type":"list"}},"events":{"toggle":{"carries":{"id":"id","open":"boolean","source":{"type":"enum","values":["user","method"]},"section":"object"}}},"actions":{"open":{"with":{"id":"id"}},"close":{"with":{"id":"id"}},"toggle":{"with":{"id":"id"}}},"css-variables":{"--sf-accordion-background-color":{"type":"color","state":"default"},"--sf-accordion-border-color":{"type":"color","state":"default"},"--sf-accordion-border-width":{"type":"length","state":"default"},"--sf-accordion-radius":{"type":"length","state":"default"},"--sf-accordion-title-color":{"type":"color","state":"default"},"--sf-accordion-content-color":{"type":"color","state":"default"},"--sf-accordion-icon-color":{"type":"color","state":"default"},"--sf-accordion-divider-color":{"type":"color","state":"open"}}}');

/***/ },

/***/ "43114319d847"
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"title":"Accordion","runtime":{"expandAll":"Expand all","collapseAll":"Collapse all"}}');

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/************************************************************************/
/******/ 	/* webpack/runtime/async module */
/******/ 	(() => {
/******/ 		const hasSymbol = typeof Symbol === "function";
/******/ 		const webpackQueues = hasSymbol ? Symbol("webpack queues") : "__webpack_queues__";
/******/ 		const webpackExports = hasSymbol ? Symbol("webpack exports") : "__webpack_exports__";
/******/ 		const webpackError = hasSymbol ? Symbol("webpack error") : "__webpack_error__";
/******/
/******/ 		const resolveQueue = (queue) => {
/******/ 			if(queue?.d < 1) {
/******/ 				queue.d = 1;
/******/ 				queue.forEach((fn) => (fn.r--));
/******/ 				queue.forEach((fn) => (fn.r-- ? fn.r++ : fn()));
/******/ 			}
/******/ 		}
/******/ 		const wrapDeps = (deps) => (deps.map((dep) => {
/******/ 			if(dep !== null && typeof dep === "object") {
/******/
/******/ 				if(dep[webpackQueues]) return dep;
/******/ 				if(dep.then) {
/******/ 					const queue = [];
/******/ 					queue.d = 0;
/******/ 					dep.then((r) => {
/******/ 						obj[webpackExports] = r;
/******/ 						resolveQueue(queue);
/******/ 					}, (e) => {
/******/ 						obj[webpackError] = e;
/******/ 						resolveQueue(queue);
/******/ 					});
/******/ 					const obj = {};
/******/
/******/ 					obj[webpackQueues] = (fn) => (fn(queue));
/******/ 					return obj;
/******/ 				}
/******/ 			}
/******/ 			const ret = {};
/******/ 			ret[webpackQueues] = x => {};
/******/ 			ret[webpackExports] = dep;
/******/ 			return ret;
/******/ 		}));
/******/ 		__webpack_require__.a = (module, body, hasAwait) => {
/******/ 			let queue;
/******/ 			hasAwait && ((queue = []).d = -1);
/******/ 			const depQueues = new Set();
/******/ 			const exports = module.exports;
/******/ 			let currentDeps;
/******/ 			let outerResolve;
/******/ 			let reject;
/******/ 			const promise = new Promise((resolve, rej) => {
/******/ 				reject = rej;
/******/ 				outerResolve = resolve;
/******/ 			});
/******/ 			promise[webpackExports] = exports;
/******/ 			promise[webpackQueues] = (fn) => (queue && fn(queue), depQueues.forEach(fn), promise["catch"](x => {}));
/******/ 			module.exports = promise;
/******/ 			const handle = (deps) => {
/******/ 				currentDeps = wrapDeps(deps);
/******/ 				let fn;
/******/ 				const getResult = () => (currentDeps.map((d) => {
/******/
/******/ 					if(d[webpackError]) throw d[webpackError];
/******/ 					return d[webpackExports];
/******/ 				}))
/******/ 				const promise = new Promise((resolve) => {
/******/ 					fn = () => (resolve(getResult));
/******/ 					fn.r = 0;
/******/ 					const fnQueue = (q) => (q !== queue && !depQueues.has(q) && (depQueues.add(q), q && !q.d && (fn.r++, q.push(fn))));
/******/ 					currentDeps.map((dep) => (dep[webpackQueues](fnQueue)));
/******/ 				});
/******/ 				return fn.r ? promise : getResult();
/******/ 			}
/******/ 			const done = (err) => ((err ? reject(promise[webpackError] = err) : outerResolve(exports)), resolveQueue(queue))
/******/ 			body(handle, done);
/******/ 			queue?.d < 0 && (queue.d = 0);
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/
/************************************************************************/
/******/
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module used 'module' so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__("0eb897441700");
/******/
/******/ })()
;