import { html, nothing } from 'lit';
import { avatarClasses, avatarContent, statusBadge, withNameTooltip } from '../../../avatar/js/templates/shared';
import { avatarPictureContext, avatarPicture } from '../../../avatar/js/picture';

// The combinations are drawn from the avatar's own parts -- sf-avatar,
// sf-avatar-group, sf-avatar-label-group, the online indicator and the verified
// badge -- the classes the avatars sheet styles. The templates wrote an older
// set (sf-avatar-round, sf-avatar--image, sf-avatar-cir, sf-avatar-check,
// sf-avatar-profile) that no sheet in the release answered: every avatar was
// drawn with no shape and no size. Each avatar was also a button with no name
// and nothing to do; an avatar here is a picture, and the visible text names the
// person.

const SIZES = ['1/4', '1/3', '1/2', '1', '2', '3'];

const SIZE_NAMES = {
  tiny: '1/4',
  extra_small: '1/3',
  extraSmall: '1/3',
  small: '1/2',
  default: '1',
  big: '2',
  extra_big: '3',
  extraBig: '3',
};

const PROFILE_SIZES = {
  small: '2',
  big: '3',
};

function step(value, fallback = '1') {
  const text = String(value ?? '').trim();
  const named = SIZE_NAMES[text] ?? text;
  return SIZES.includes(named) ? named : fallback;
}

// How far the avatars of a group overlap is the group sheet's, from the
// avatars' own size (component.avatars 1.11.0, owner decision C152 (6): 4 up
// to size 1, 8 at 2 and 3). The group prints no overlap modifier since 1.5.1;
// the sf-avatar-group--size-* modifiers are dated aliases (journal
// class-avatar-group-overlap-by-size).

// Up to four people are shown; the fifth place is «+N» (C152 (6)).
const SHOWN = 4;

function avatar(options) {
  // sf-avatar's drawing (js/picture.js): the photo over the initials, else
  // the initials, else the glyph.
  const context = avatarPictureContext({
    size: options.size,
    imageUrl: options.imageUrl || '',
    text: options.text || '',
    status: options.status || 'none',
    rootClass: options.rootClass || '',
    component: options.component,
  });
  return html`
    <span class=${avatarClasses(context)} style=${options.rootStyle || nothing}>
      ${avatarContent(context)} ${statusBadge(context)}
    </span>
  `;
}

function status(context) {
  if (context.check) return 'verified';
  if (context.active) return 'online';
  return 'none';
}

function renderDefaultTemplate(context) {
  return avatar({
    size: step(context.roundSize || context.avatarSize),
    imageUrl: context.imageUrl,
    status: status(context),
    rootClass: context.rootClass,
    rootStyle: context.rootStyle,
    component: context.component,
  });
}

function labelGroup(context, {size, imageUrl, title, text, icon}) {
  return html`
    <div class=${['sf-avatar-label-group', `sf-avatar-label-group--size-${size}`, 'flex', 'items-cross-center', context.rootClass]
      .filter(Boolean)
      .join(' ')} style=${context.rootStyle || nothing}>
      ${avatar({ size, imageUrl, component: context.component })}
      <div class="sf-avatar-label-group-container flex flex-col">
        ${title ? html`<div class="sf-avatar-label-group-title">${title}</div>` : nothing}
        ${text
          ? html`<div class="sf-avatar-label-group-text">
              ${icon ? html`<i class="sf-icon" aria-hidden="true">${icon}</i>` : nothing}
              <span>${text}</span>
            </div>`
          : nothing}
      </div>
    </div>
  `;
}

function renderUserTemplate(context) {
  return labelGroup(context, {
    size: step(context.avatarSize),
    imageUrl: context.imageUrl,
    title: context.name,
    text: context.source,
    icon: context.source ? 'link' : '',
  });
}

function renderLabelTemplate(context) {
  return labelGroup(context, {
    size: step(context.labelSize || context.avatarSize),
    imageUrl: context.avatarUrl,
    title: context.labelText,
    text: context.labelSecondText,
  });
}

// One person of the group: the picture (photo over the initials, C152 (2)),
// role img named by the person, the hue of the name (C17, C152 (6)) and the
// name in a tooltip, since a group prints no names (C152 (7)).
function member(item, size, index, context) {
  const name = String(item.name ?? item.heading ?? '').trim();
  const picture = avatarPictureContext({
    size,
    imageUrl: item.imageUrl || item.image_url,
    name,
    text: item.text || item.initials,
    hue: item.hue || (name ? 'auto' : ''),
    status: item.status,
    component: context.component,
  });
  const tipId = name && context.uid ? `${context.uid}-tip-${index}` : '';
  const face = html`<span class=${avatarClasses(picture)} role="img" aria-label=${name || picture.text || nothing}
    data-tooltip=${tipId || nothing}>${avatarContent(picture)} ${statusBadge(picture)}</span>`;
  return withNameTooltip(face, name, tipId);
}

// The row of the full list behind «+N»: the picture and the printed name.
function listRow(item) {
  const name = String(item.name ?? item.heading ?? '').trim();
  return html`<li class="sf-avatar-group-list-item">${avatarPicture({
    size: '1/2',
    imageUrl: item.imageUrl || item.image_url,
    name,
    text: item.text || item.initials,
    hue: item.hue || (name ? 'auto' : ''),
  })}<span class="sf-avatar-group-list-name">${name || item.text || item.initials || ''}</span></li>`;
}

// The group (owner decision C152 (6), 2026-11-14): up to four people, the
// fifth place «+N» with the exact number of the others. When the host gives
// the whole list (more than four in avatars) «+N» is a button of the same
// size and shape that opens the list of everyone in an sf-popover; with only
// a number (avatars-more) it stays text. The group is named «Участники: N»,
// N everyone it stands for. Before: every avatar shown, «+N» a grey avatar
// with no action or name, the group nameless.
function renderGroupTemplate(context) {
  const size = step(context.roundSize, '1/2');
  const list = Array.isArray(context.avatars) ? context.avatars : [];
  const more = String(context.avatarsMore ?? '').trim();
  const extra = /^\d+$/u.test(more) ? Number(more) : 0;
  const shown = list.slice(0, SHOWN);
  const hidden = list.length - shown.length + extra;
  const total = list.length + extra;
  const words = context.words || {};
  const groupLabel = words.group ? words.group(total) : '';
  const moreLabel = words.more ? words.more(hidden) : '';
  const withList = list.length > SHOWN;
  if (withList) {
    globalThis.SF?.Loader?.ensurePlugin?.('cl-popover');
  }
  if (shown.some((item) => String(item.name ?? item.heading ?? '').trim())) {
    globalThis.SF?.Loader?.ensurePlugin?.('tooltip');
  }

  let tail = nothing;
  if (withList) {
    const plus = avatarPictureContext({ size, text: `+${hidden}` });
    tail = html`<sf-popover class="sf-avatar-group-more" placement="bottom-start" label=${moreLabel || nothing}>
      <button slot="trigger" type="button" class=${avatarClasses(plus)} aria-label=${moreLabel || nothing}>${avatarContent(plus)}</button>
      <div slot="content"><ul class="sf-avatar-group-list">${list.map((item) => listRow(item))}</ul></div>
    </sf-popover>`;
  } else if (hidden > 0 || (more && !extra)) {
    // No list from the host: «+N» (or the host's short text) is text.
    tail = avatar({ size, text: extra ? `+${hidden}` : more, component: context.component });
  }

  return html`
    <div class=${['sf-avatar-group', 'flex', 'items-cross-center', context.rootClass]
      .filter(Boolean)
      .join(' ')} style=${context.rootStyle || nothing} role="group" aria-label=${groupLabel || nothing}>
      <div class="sf-avatar-group-avatars flex">
        ${shown.map((item, index) => member(item, size, index, context))}
        ${tail}
      </div>
    </div>
  `;
}

function renderProfileTemplate(context) {
  return avatar({
    size: PROFILE_SIZES[context.profileSize] || step(context.profileSize, '3'),
    imageUrl: context.imageUrl,
    status: 'verified',
    rootClass: context.rootClass,
    rootStyle: context.rootStyle,
    component: context.component,
  });
}

export function renderAvatarsTemplate(context) {
  switch (context.templateName) {
    case 'user':
      return renderUserTemplate(context);
    case 'group':
      return renderGroupTemplate(context);
    case 'label':
      return renderLabelTemplate(context);
    case 'profile':
      return renderProfileTemplate(context);
    default:
      return renderDefaultTemplate(context);
  }
}
