import { isPlainObject } from './canonical.mjs';
import { pageText } from '../page-language.js';
import { defineTagAliases } from '../tag-aliases.js';
import { activeSortableSession, registerSortableDropTarget } from './sortable.mjs';
import { holdOpenSurfaceMark, isTopOpenSurface } from '../open-surface-mark.js';

// Editor canvas overlay. It draws hover and selection frames, an action toolbar
// above the selected block and one insertion point at the seam under the pointer
// over a rendered Composition Document without touching the canvas DOM: the
// published HTML stays byte-identical. The host supplies node descriptions and
// actions and performs every change.
//
// Placed in the same scroller as its canvas, the overlay's parts lie in the
// scrolled content and travel with it, so nothing runs on scroll and nothing
// trails a frame behind; the script measures only when geometry changes. Placed
// outside it, the parts stay fixed to the viewport and follow by script.
//
// Framed mode (attachFrame + setNodes) draws the same chrome over a same-origin
// iframe fed a flat node list: frame coordinates are mapped to the host page
// through the iframe's position, borders, padding, scale and the frame's own
// scroll, and a plain-string inline edit happens on the element inside the frame.

// The names sf-editor-overlay's component.json declares (standard 1.3.8
// §8, vocabulary 1.1.5): select {ids, id}, apply {action, scope: entry, ids}
// (one entry's own action, §18.3), insert, move {ids, id, parent, position}
// (one manual move) and change {id, value, previous} for a plain-string edit.
// select, move and insert keep their names and add the vocabulary's fields to
// the former ones (node_id, parent_id stay for the composition host); apply
// and change are new names, followed by sf-composition-overlay-action and
// -edit with their former details until 2026-12-01 (aliases.json). Since
// 2026-11-03 the tag is sf-editor-overlay: each name is also sent under the
// former tag (sf-composition-overlay-*, the same detail) until 2027-01-01.
export const OVERLAY_EVENTS = Object.freeze({
  select: 'sf-editor-overlay-select',
  action: 'sf-editor-overlay-apply',
  insert: 'sf-editor-overlay-insert',
  move: 'sf-editor-overlay-move',
  edit: 'sf-editor-overlay-change',
});

export const OVERLAY_EVENTS_FORMER_TAG = Object.freeze({
  select: 'sf-composition-overlay-select',
  action: 'sf-composition-overlay-apply',
  insert: 'sf-composition-overlay-insert',
  move: 'sf-composition-overlay-move',
  edit: 'sf-composition-overlay-change',
});
const FORMER_TAG_NAME = new Map(Object.keys(OVERLAY_EVENTS).map((key) => [OVERLAY_EVENTS[key], OVERLAY_EVENTS_FORMER_TAG[key]]));

export const OVERLAY_EVENTS_LEGACY = Object.freeze({
  action: 'sf-composition-overlay-action',
  edit: 'sf-composition-overlay-edit',
});

const LEGACY_DETAIL = {
  action: (detail) => ({ action_id: detail.action, node_id: detail.ids[0] ?? null }),
  edit: (detail) => ({ node_id: detail.id, value: detail.value, previous: detail.previous }),
};

const MESSAGES = {
  ru: { picked: 'Перемещение: {label}. Стрелки выбирают место, Enter — положить, Escape — отменить.', cancelled: 'Перемещение отменено.', tree: 'Структура страницы', toolbar: 'Действия', insert: 'Вставить', insertAt: 'Вставить в «{slot}», позиция {index}', position: '{index} из {total}', selected: 'Выбрано: {label}', editing: 'Редактирование: {label}. Enter — сохранить, Escape — отменить.' },
  en: { picked: 'Moving {label}. Arrows choose a place, Enter drops, Escape cancels.', cancelled: 'Move cancelled.', tree: 'Page structure', toolbar: 'Actions', insert: 'Insert', insertAt: 'Insert into “{slot}”, position {index}', position: '{index} of {total}', selected: 'Selected: {label}', editing: 'Editing {label}. Enter saves, Escape cancels.' },
};

const ACTION_ID = /^[a-z][a-z0-9-]{0,63}$/u;
const ACTION_KEYS = new Set(['id', 'label', 'icon', 'shortcut', 'disabled', 'tone']);
const ICON_NAME = /^[a-z][a-z0-9_]{0,63}$/u;
// The action a drag starts from is the one drawn as a grip.
const GRIP_ICON = 'drag_indicator';
// Blocks and the frame reach their place together.
const GLIDE = { duration: 180, easing: 'cubic-bezier(.2, 0, 0, 1)' };
// The seam takes the pointer about this far either side, and stays this long after it leaves.
const SEAM_REACH = 10;
const SEAM_LEAVE = 140;
// A drag starts after this many pixels and scrolls the canvas near its edges.
const DRAG_START = 4;
const DRAG_EDGE = 48;
const DRAG_STEP = 10;
const SCROLLS = /^(auto|scroll)$/u;
const format = (template, values) => template.replace(/\{(\w+)\}/gu, (_, key) => String(values[key] ?? ''));

/** Flattens a Document into overlay nodes in document order. */
export function overlayNodes(document) {
  const nodes = [];
  const visit = (node, parent, slot, index, level) => {
    if (!isPlainObject(node) || typeof node.id !== 'string') return;
    const entry = { id: node.id, type: node.type, parent, slot, index, level, slots: {} };
    nodes.push(entry);
    for (const [name, children] of Object.entries(isPlainObject(node.slots) ? node.slots : {})) {
      if (!Array.isArray(children)) continue;
      entry.slots[name] = children.map((child) => child?.id).filter((id) => typeof id === 'string');
      children.forEach((child, childIndex) => visit(child, node.id, name, childIndex, level + 1));
    }
  };
  visit(document?.root, null, null, 0, 1);
  return nodes;
}

export function checkOverlayActions(actions) {
  if (!Array.isArray(actions) || actions.length > 16) throw new TypeError('Overlay actions must be a list of up to 16 entries');
  return actions.map((action) => {
    if (!isPlainObject(action) || !ACTION_ID.test(action.id || '') || typeof action.label !== 'string' || !action.label.trim()
      || Object.keys(action).some((key) => !ACTION_KEYS.has(key))) {
      throw new TypeError('Overlay actions have an opaque id, a label and optionally icon, shortcut, disabled and tone');
    }
    if ((action.icon !== undefined && !ICON_NAME.test(String(action.icon)))
      || (action.shortcut !== undefined && (typeof action.shortcut !== 'string' || !action.shortcut.trim()))
      || (action.disabled !== undefined && typeof action.disabled !== 'boolean')
      || (action.tone !== undefined && action.tone !== 'danger')) {
      throw new TypeError(`Overlay action ${action.id} has an icon name, a shortcut string, a boolean disabled and the tone "danger" at most`);
    }
    const checked = { id: action.id, label: action.label };
    for (const key of ['icon', 'shortcut', 'disabled', 'tone']) if (action[key] !== undefined) checked[key] = action[key];
    return Object.freeze(checked);
  });
}

const SHORTCUT_MODIFIERS = { '⌥': 'alt', '⇧': 'shift', '⌘': 'mod', '⌃': 'mod' };
const SHORTCUT_KEYS = { '↑': 'ArrowUp', '↓': 'ArrowDown', '←': 'ArrowLeft', '→': 'ArrowRight', '⏎': 'Enter', '↵': 'Enter', '⎋': 'Escape', '⌦': 'Delete' };

/**
 * Whether a keydown is an action's shortcut: the symbols the tooltip shows, as in
 * "⌥↑", "⌘D", "⌫" or "Enter". ⌘ is Command or Control, and ⌫ is Backspace or Delete.
 */
export function shortcutMatches(shortcut, event) {
  let rest = String(shortcut).trim();
  const held = { alt: false, shift: false, mod: false };
  while (rest.length > 1 && SHORTCUT_MODIFIERS[rest[0]]) {
    held[SHORTCUT_MODIFIERS[rest[0]]] = true;
    rest = rest.slice(1);
  }
  if (Boolean(event.altKey) !== held.alt || Boolean(event.shiftKey) !== held.shift || Boolean(event.metaKey || event.ctrlKey) !== held.mod) return false;
  if (rest === '⌫') return event.key === 'Backspace' || event.key === 'Delete';
  const key = SHORTCUT_KEYS[rest] ?? rest;
  return key.length === 1 ? String(event.key).toLowerCase() === key.toLowerCase() : event.key === key;
}

const NODE_KEYS = new Set(['id', 'kind', 'rect', 'element', 'label', 'parent', 'editable']);
const finite = (value) => typeof value === 'number' && Number.isFinite(value);
// Elements of the frame belong to another realm, so `instanceof Element` is false for them.
const isElement = (value) => Boolean(value) && typeof value === 'object' && value.nodeType === 1 && typeof value.getBoundingClientRect === 'function';

/**
 * Checks a framed canvas's flat node list: [{id, kind, rect? | element?, label?,
 * parent?, editable?}]. rect is in frame-document coordinates {x, y, width,
 * height}; element is a node inside the frame. Returns frozen entries.
 */
export function checkOverlayNodes(nodes) {
  if (!Array.isArray(nodes)) throw new TypeError('Overlay nodes must be a list');
  const seen = new Set();
  const list = nodes.map((node) => {
    if (!isPlainObject(node) || Object.keys(node).some((key) => !NODE_KEYS.has(key))) {
      throw new TypeError('Overlay nodes have id, kind, rect or element, label, parent and editable only');
    }
    if (typeof node.id !== 'string' || !node.id || seen.has(node.id)) throw new TypeError('Overlay nodes have unique non-empty string ids');
    if (typeof node.kind !== 'string' || !node.kind) throw new TypeError(`Overlay node ${node.id} names its kind`);
    const { rect, element } = node;
    if (rect !== undefined && (!isPlainObject(rect) || !['x', 'y', 'width', 'height'].every((key) => finite(rect[key])) || rect.width < 0 || rect.height < 0)) {
      throw new TypeError(`Overlay node ${node.id} has a rect {x, y, width, height} of finite numbers`);
    }
    if (element !== undefined && !isElement(element)) throw new TypeError(`Overlay node ${node.id} has an element`);
    if (rect === undefined && element === undefined) throw new TypeError(`Overlay node ${node.id} has a rect or an element`);
    if (node.label !== undefined && typeof node.label !== 'string') throw new TypeError(`Overlay node ${node.id} has a string label`);
    if (node.parent !== undefined && node.parent !== null && (typeof node.parent !== 'string' || node.parent === node.id)) {
      throw new TypeError(`Overlay node ${node.id} names another node as its parent`);
    }
    if (node.editable !== undefined && typeof node.editable !== 'boolean') throw new TypeError(`Overlay node ${node.id} has a boolean editable`);
    if (node.editable && element === undefined) throw new TypeError(`Overlay node ${node.id} is editable only with an element`);
    seen.add(node.id);
    return Object.freeze({
      id: node.id,
      kind: node.kind,
      rect: rect === undefined ? null : Object.freeze({ x: rect.x, y: rect.y, width: rect.width, height: rect.height }),
      element: element ?? null,
      label: node.label ?? null,
      parent: node.parent ?? null,
      editable: node.editable === true,
    });
  });
  const byId = new Map(list.map((node) => [node.id, node]));
  for (const node of list) {
    const visited = new Set([node.id]);
    for (let parent = node.parent; parent !== null; parent = byId.get(parent).parent) {
      if (!byId.has(parent)) throw new TypeError(`Overlay node ${node.id} names a parent that is not in the list`);
      if (visited.has(parent)) throw new TypeError(`Overlay node ${node.id} is its own ancestor`);
      visited.add(parent);
    }
  }
  return Object.freeze(list);
}

/** Overlay entries for a checked flat list, in list order; the top level is parent null, slot "default". */
export function flatOverlayNodes(list) {
  const entries = list.map((node) => ({ id: node.id, type: node.kind, kind: node.kind, label: node.label, parent: node.parent, slot: 'default', index: 0, level: 1, slots: {}, flat: node }));
  const byId = new Map(entries.map((entry) => [entry.id, entry]));
  const counts = new Map();
  for (const entry of entries) {
    const key = entry.parent ?? '';
    entry.index = counts.get(key) || 0;
    counts.set(key, entry.index + 1);
    if (entry.parent) (byId.get(entry.parent).slots.default ||= []).push(entry.id);
    for (let parent = entry.parent; parent; parent = byId.get(parent).parent) entry.level += 1;
  }
  return entries;
}

/**
 * Where a frame's viewport lies on the host page. rect is the iframe's border box
 * on the host (after any transform or zoom), layout its untransformed border box
 * size (offsetWidth/offsetHeight), border and padding its own {top, right,
 * bottom, left} in CSS px, inner the frame's viewport size in its own px and
 * scroll the frame's scroll position. The scale is rect over layout; without a
 * layout size it is taken from the parts, which the viewport's whole-pixel size
 * makes less exact under zoom.
 */
export function frameViewport({ rect, layout = null, border, padding, inner, scroll = { x: 0, y: 0 } }) {
  const outerWidth = layout?.width > 0 ? layout.width : border.left + padding.left + inner.width + padding.right + border.right;
  const outerHeight = layout?.height > 0 ? layout.height : border.top + padding.top + inner.height + padding.bottom + border.bottom;
  const scaleX = outerWidth > 0 && rect.width > 0 ? rect.width / outerWidth : 1;
  const scaleY = outerHeight > 0 && rect.height > 0 ? rect.height / outerHeight : 1;
  return {
    left: rect.left + (border.left + padding.left) * scaleX,
    top: rect.top + (border.top + padding.top) * scaleY,
    width: inner.width * scaleX,
    height: inner.height * scaleY,
    scaleX,
    scaleY,
    scrollX: scroll.x,
    scrollY: scroll.y,
  };
}

/** A box in the frame's viewport coordinates {x, y, width, height}, mapped to the host page. */
export function frameRectToHost(box, view) {
  const left = view.left + box.x * view.scaleX;
  const top = view.top + box.y * view.scaleY;
  const width = box.width * view.scaleX;
  const height = box.height * view.scaleY;
  return { x: left, y: top, left, top, width, height, right: left + width, bottom: top + height };
}

const plainText = (element) => (element.textContent || '').replace(/\s+/gu, ' ').trim();
const px = (value) => Number.parseFloat(value) || 0;
const intersect = (a, b) => ({ left: Math.max(a.left, b.left), top: Math.max(a.top, b.top), right: Math.min(a.right, b.right), bottom: Math.min(a.bottom, b.bottom) });
const calm = () => globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;

// The element whose scrolling carries this one: the nearest ancestor that scrolls
// (or is fixed, so nothing carries it further), null for the page itself.
function nearestScroller(start) {
  const { body, documentElement: root } = globalThis.document;
  for (let element = start?.parentElement; element && element !== body && element !== root; element = element.parentElement) {
    const own = globalThis.getComputedStyle(element);
    if (SCROLLS.test(own.overflowY) || SCROLLS.test(own.overflowX) || own.position === 'fixed') return element;
  }
  return null;
}

// One manual move (vocabulary 1.1.5 §5 move, {id, parent, position}) in the
// vocabulary's words beside the composition host's.
function moveDetail(id, descriptor) {
  return { node_id: id, ...descriptor, ids: [id], id, parent: descriptor.parent_id ?? null, position: descriptor.index };
}

// base: the class made from sf-editor-overlay's component.json
// (manifest-host.mjs); without it the overlay is a plain element.
export function defineCompositionOverlay(registry = globalThis.customElements, { base = null } = {}) {
  if (!registry || typeof globalThis.HTMLElement !== 'function') return null;
  const existing = registry.get('sf-editor-overlay');
  if (existing) return existing;

  class SfCompositionOverlay extends (base || globalThis.HTMLElement) {
    constructor() {
      super();
      this.canvas = null;
      this.nodes = [];
      this.byId = new Map();
      this.describe = () => ({});
      this._actions = [];
      this.selectedId = null;
      this.hoverId = null;
      this._insertionTarget = null;
      this.connection = null;
      this.frameRequest = 0;
      this.resizeObserver = null;
      this.layer = null;
      this.dropFilter = () => true;
      this.moving = null;
      this.unregisterDrop = null;
      this.dropHint = null;
      this.iframe = null;
      this.frameDoc = null;
      this.frameConnection = null;
      this.view = null;
      this.elementIds = new Map();
      this.rectNodes = [];
      this.editing = null;
      this.scroller = null;
      this.followConnection = null;
      this.observed = [];
      this.offsets = new Map();
      this.glide = null;
      this.pointer = null;
      this.pointerRequest = 0;
      this.seam = null;
      this.seamTimer = 0;
      this.gripDrag = null;
      this.actionParts = new Map();
    }

    // actions, messages and insertion-target are settings of the manifest
    // (properties); a write goes through the same checks as the host port's
    // setActions, setMessages and setInsertionTarget, which stay.
    get actions() {
      return this._actions;
    }

    set actions(value) {
      this.setActions(value ?? []);
    }

    get insertionTarget() {
      return this._insertionTarget;
    }

    set insertionTarget(value) {
      this.setInsertionTarget(value ?? null);
    }

    set messages(value) {
      this.setMessages(value);
    }

    get messages() {
      // In the page's language through pageText, as every component's words are.
      const words = Object.fromEntries(Object.keys(MESSAGES.en).map((key) => [key, pageText(MESSAGES, key, this, 'sf-editor-overlay')]));
      return { ...words, ...(this.customMessages || {}) };
    }

    connectedCallback() {
      super.connectedCallback?.();
      if (!this.layer) this.buildLayer();
      const canvasId = this.getAttribute('for');
      const frameId = this.getAttribute('frame');
      if (frameId && !this.canvas && !this.iframe) {
        const iframe = globalThis.document.getElementById(frameId);
        if (iframe) this.attachFrame(iframe);
      } else if (canvasId && !this.canvas && !this.iframe) {
        const canvas = globalThis.document.getElementById(canvasId);
        if (canvas) this.attach(canvas);
      } else if (this.canvas || this.iframe) {
        this.bind();
      }
    }

    disconnectedCallback() {
      super.disconnectedCallback?.();
      this.unbind();
    }

    static get observedAttributes() {
      return [...new Set([...(super.observedAttributes ?? []), 'placement'])];
    }

    attributeChangedCallback(name, ...values) {
      super.attributeChangedCallback?.(name, ...values);
      if (name === 'placement') this.schedule();
    }

    buildLayer() {
      const doc = globalThis.document;
      this.classList.add('sf-composition-overlay');
      this.layer = doc.createElement('div');
      this.layer.className = 'sf-composition-overlay-layer';
      this.layer.setAttribute('aria-hidden', 'true');
      this.hoverFrame = this.frame('hover');
      this.selectedFrame = this.frame('selected');
      this.insertionLayer = doc.createElement('div');
      this.insertionLayer.className = 'sf-composition-overlay-insertions';
      this.toolbar = doc.createElement('div');
      this.toolbar.className = 'sf-composition-overlay-toolbar';
      this.toolbar.setAttribute('role', 'toolbar');
      this.toolbar.hidden = true;
      // The rail holds the toolbar's sticky range in the scrolled content.
      this.rail = doc.createElement('div');
      this.rail.className = 'sf-composition-overlay-rail';
      this.rail.append(this.toolbar);
      this.tree = doc.createElement('div');
      this.tree.className = 'sf-composition-overlay-tree';
      this.tree.setAttribute('role', 'tree');
      this.tree.tabIndex = 0;
      this.live = doc.createElement('div');
      this.live.className = 'sf-composition-overlay-live';
      this.live.setAttribute('aria-live', 'polite');
      this.append(this.tree, this.rail, this.insertionLayer, this.layer, this.live);
      this.layer.append(this.hoverFrame, this.selectedFrame);
    }

    frame(kind) {
      const frame = globalThis.document.createElement('div');
      frame.className = `sf-composition-overlay-frame sf-composition-overlay-frame--${kind}`;
      frame.hidden = true;
      // Hover is a bare frame; only the selection carries the move handle.
      if (kind === 'selected') {
        const label = globalThis.document.createElement('span');
        label.className = 'sf-composition-overlay-label';
        label.hidden = true;
        frame.append(label);
      }
      return frame;
    }

    /** Binds the overlay to a rendered canvas; the canvas is never modified. */
    attach(canvas) {
      if (!(canvas instanceof globalThis.Element)) throw new TypeError('Overlay canvas must be an element');
      if (!this.layer) this.buildLayer();
      this.unbind();
      this.canvas = canvas;
      this.iframe = null;
      this.removeAttribute('data-sf-overlay-mode');
      this.layer.style.clipPath = '';
      this.insertionLayer.style.clipPath = '';
      if (this.isConnected) this.bind();
      return this;
    }

    /** Binds the overlay to a same-origin iframe canvas fed by setNodes; the frame's HTML is never modified by the overlay. */
    attachFrame(iframe) {
      if (!isElement(iframe) || iframe.localName !== 'iframe') throw new TypeError('Overlay frame must be an iframe element');
      if (!this.layer) this.buildLayer();
      this.unbind();
      this.canvas = null;
      this.iframe = iframe;
      this.setAttribute('data-sf-overlay-mode', 'frame');
      if (this.isConnected) this.bind();
      return this;
    }

    bind() {
      if (this.connection || (!this.canvas && !this.iframe)) return;
      this.connection = new AbortController();
      const options = { signal: this.connection.signal };
      const passive = { ...options, passive: true };
      if (this.iframe) {
        // A new letter (srcdoc, navigation) is a new document: listen to it again.
        this.iframe.addEventListener('load', () => this.bindFrameDocument(), options);
        this.iframe.addEventListener('pointerleave', () => this.onPointerGone(), passive);
      } else {
        this.canvas.addEventListener('pointermove', (event) => this.onPointerMove(event), passive);
        this.canvas.addEventListener('pointerleave', () => this.onPointerGone(), passive);
        this.canvas.addEventListener('click', (event) => this.onCanvasClick(event), { ...options, capture: true });
      }
      this.tree.addEventListener('keydown', (event) => this.onTreeKey(event), options);
      this.tree.addEventListener('focus', () => {
        this.setAttribute('data-sf-overlay-focus', '');
        if (!this.selectedId && this.nodes.length) this.select(this.nodes[0].id);
      }, options);
      this.tree.addEventListener('blur', () => this.removeAttribute('data-sf-overlay-focus'), options);
      this.toolbar.addEventListener('click', (event) => this.onToolbarClick(event), options);
      this.toolbar.addEventListener('keydown', (event) => this.onToolbarKey(event), options);
      this.insertionLayer.addEventListener('click', (event) => this.onInsertionClick(event), options);
      this.toolbar.addEventListener('pointerdown', (event) => this.onToolbarPointerDown(event), options);
      this.insertionLayer.addEventListener('pointerover', () => this.holdSeam(), passive);
      this.insertionLayer.addEventListener('pointerout', () => this.leaveSeam(), passive);
      // Scrolling inside the canvas moves its nodes under the parts; the scroller around it carries both.
      this.canvas?.addEventListener('scroll', () => this.schedule(), { ...passive, capture: true });
      globalThis.addEventListener('resize', () => this.schedule(), passive);
      if (typeof globalThis.ResizeObserver === 'function') {
        this.resizeObserver = new globalThis.ResizeObserver(() => this.schedule());
        this.observeGeometry();
      }
      this.unregisterDrop = registerSortableDropTarget({
        resolve: (x, y, dragSession) => (this.acceptsDrag(dragSession) ? this.resolveDrop(x, y, null) : null),
        keyboardTargets: (dragSession) => (this.acceptsDrag(dragSession) ? this.dropTargets(null) : []),
        drop: (dragSession, descriptor) => this.emit(OVERLAY_EVENTS.insert, { ...descriptor, parent: descriptor.parent_id ?? null, item: dragSession.item, from: dragSession.from, mode: dragSession.mode }),
        leave: () => this.showDropHint(null),
      });
      this.selectedFrame.firstChild.addEventListener('pointerdown', (event) => this.onHandleDown(event), options);
      this.setAttribute('data-sf-overlay', 'connected');
      this.renderTree();
      if (this.iframe) this.bindFrameDocument();
      this.schedule();
    }

    /** Listens to the frame's current document and window; called on bind and on every frame load. */
    bindFrameDocument() {
      if (this.editing) this.finishEdit(false);
      this.frameConnection?.abort();
      this.frameConnection = null;
      let doc = null;
      try {
        doc = this.iframe.contentDocument;
      } catch {
        doc = null;
      }
      const win = doc?.defaultView || null;
      this.frameDoc = win ? doc : null;
      this.offsets = new Map();
      if (!this.frameDoc) {
        this.observeGeometry();
        // A cross-origin or not yet available frame: nothing is drawn over it.
        this.setAttribute('data-sf-overlay-frame', 'unreachable');
        this.schedule();
        return;
      }
      this.removeAttribute('data-sf-overlay-frame');
      this.frameConnection = new AbortController();
      const options = { signal: this.frameConnection.signal };
      const passive = { ...options, passive: true };
      doc.addEventListener('pointermove', (event) => {
        this.setHover(this.frameNodeAt(event));
        this.trackPointer(event.clientX, event.clientY, true);
      }, passive);
      doc.addEventListener('pointerout', (event) => { if (!event.relatedTarget) this.onPointerGone(); }, passive);
      doc.addEventListener('click', (event) => this.onFrameClick(event), { ...options, capture: true });
      doc.addEventListener('dblclick', (event) => this.onFrameDoubleClick(event), { ...options, capture: true });
      doc.addEventListener('keydown', (event) => this.onFrameKey(event), { ...options, capture: true });
      win.addEventListener('scroll', () => this.schedule(), { ...passive, capture: true });
      win.addEventListener('resize', () => this.schedule(), passive);
      this.observeGeometry();
      this.schedule();
    }

    // What changes the parts' geometry: the canvas, its document, the scroller's
    // port and the selected node. Scrolling changes none of them.
    observeGeometry() {
      const observer = this.resizeObserver;
      if (!observer) return;
      const root = this.frameDoc?.documentElement;
      const wanted = [this.canvas || this.iframe, this.scroller, root, this.frameDoc?.body, this.selectedElement()].filter(Boolean);
      if (wanted.length === this.observed.length && wanted.every((element, index) => element === this.observed[index])) return;
      observer.disconnect();
      for (const element of wanted) observer.observe(element);
      this.observed = wanted;
    }

    selectedElement() {
      const node = this.selectedId ? this.byId.get(this.selectedId) : null;
      if (!node) return null;
      return node.flat ? node.flat.element : this.element(node.id);
    }

    unbind() {
      this.finishEdit(false);
      this.frameConnection?.abort();
      this.frameConnection = null;
      this.frameDoc = null;
      this.pointerDrag?.abort();
      this.pointerDrag = null;
      this.endGripDrag(false);
      this.settleGlide();
      this.clearSeam();
      this.followConnection?.abort();
      this.followConnection = null;
      this.observed = [];
      this.unregisterDrop?.();
      this.unregisterDrop = null;
      this.moving = null;
      this.connection?.abort();
      this.connection = null;
      this.resizeObserver?.disconnect();
      this.resizeObserver = null;
      if (this.frameRequest) globalThis.cancelAnimationFrame(this.frameRequest);
      this.frameRequest = 0;
      if (this.pointerRequest) globalThis.cancelAnimationFrame(this.pointerRequest);
      this.pointerRequest = 0;
      if (this.canvas || this.iframe) this.setAttribute('data-sf-overlay', 'disposed');
    }

    /** Supplies the Document structure and a describe(node) → {label, badges}. */
    setDocument(document, { describe } = {}) {
      this.elementIds = new Map();
      this.rectNodes = [];
      this.replaceNodes(overlayNodes(document), describe);
      return this;
    }

    /**
     * Supplies a framed canvas's flat node list [{id, kind, rect? | element?,
     * label?, parent?, editable?}] in selection order, and an optional
     * describe(node) → {label, badges}; without it the label is node.label or its kind.
     */
    setNodes(nodes, { describe } = {}) {
      const list = checkOverlayNodes(nodes);
      this.elementIds = new Map(list.filter((node) => node.element).map((node) => [node.element, node.id]));
      const entries = flatOverlayNodes(list);
      this.rectNodes = entries.filter((entry) => entry.flat.rect && !entry.flat.element);
      if (this.editing) {
        const next = list.find((node) => node.id === this.editing.id);
        if (!next || next.element !== this.editing.element || !next.editable) this.finishEdit(false);
      }
      this.replaceNodes(entries, typeof describe === 'function' ? describe : (node) => ({ label: node.label || node.kind }));
      return this;
    }

    replaceNodes(nodes, describe) {
      const previous = this.selectedId ? this.byId.get(this.selectedId) : null;
      const active = globalThis.document.activeElement;
      const focused = Boolean(active) && (this.toolbar?.contains(active) || this.insertionLayer?.contains(active));
      this.settleGlide();
      const before = this.offsets;
      this.elementIndex = null;
      this.nodes = nodes;
      this.byId = new Map(this.nodes.map((node) => [node.id, node]));
      if (typeof describe === 'function') this.describe = describe;
      this.renderTree();
      // A selected node the host removed is deselected (and announced), so its
      // toolbar and insertion places do not stay on screen. When keyboard focus
      // was on a disappearing button, the parent (or first node) is selected and
      // focus moves to the tree instead of dropping onto the page body.
      if (this.selectedId !== null && !this.byId.has(this.selectedId)) {
        const fallback = previous?.parent && this.byId.has(previous.parent) ? previous.parent : this.nodes[0]?.id ?? null;
        this.select(focused ? fallback : null, { focus: focused });
      }
      if (!this.startGlide(before)) this.schedule();
    }

    /** Re-measures on the next frame, after a change no observer reports (a transform on an ancestor of the canvas). */
    refresh() {
      this.schedule();
      return this;
    }

    setActions(actions) {
      this._actions = checkOverlayActions(actions);
      this.renderToolbar();
      this.schedule();
      return this;
    }

    setMessages(messages) {
      this.customMessages = isPlainObject(messages) ? { ...messages } : null;
      this.renderTree();
      return this;
    }

    /** filter({parent_id, slot, index}, item) → boolean hides invalid places. */
    setDropFilter(filter) {
      this.dropFilter = typeof filter === 'function' ? filter : () => true;
      return this;
    }

    // Named so, not accepts: that is the setting's property (component.json).
    acceptsDrag(dragSession) {
      const groups = (this.getAttribute('accepts') || '').split(/\s+/u).filter(Boolean);
      return Boolean(dragSession && groups.includes(dragSession.group));
    }

    // The overlay's aliases.json sends the name under the former tag after
    // it; an overlay defined without its manifest sends it here.
    emit(type, detail) {
      const frozen = Object.freeze(detail);
      const allowed = this.dispatchEvent(new globalThis.CustomEvent(type, { bubbles: true, composed: true, detail: frozen }));
      if (!this.__sfAliases && FORMER_TAG_NAME.has(type)) this.dispatchEvent(new globalThis.CustomEvent(FORMER_TAG_NAME.get(type), { bubbles: true, composed: true, detail: frozen }));
      return allowed;
    }

    // A renamed event: the overlay's aliases.json sends the former name after
    // it (the adapters below); an overlay defined without its manifest sends
    // both here. Answers false when a listener cancelled either.
    sendRenamed(key, detail, cancelable = false) {
      const event = new globalThis.CustomEvent(OVERLAY_EVENTS[key], { bubbles: true, composed: true, cancelable, detail: Object.freeze(detail) });
      let allowed = this.dispatchEvent(event);
      if (!this.__sfAliases) {
        const former = new globalThis.CustomEvent(OVERLAY_EVENTS_FORMER_TAG[key], { bubbles: true, composed: true, cancelable, detail: event.detail });
        allowed = this.dispatchEvent(former) && allowed;
        if (former.defaultPrevented) event.preventDefault();
        const legacy = new globalThis.CustomEvent(OVERLAY_EVENTS_LEGACY[key], { bubbles: true, composed: true, cancelable, detail: Object.freeze(LEGACY_DETAIL[key](detail)) });
        allowed = this.dispatchEvent(legacy) && allowed;
      }
      return allowed && !event.defaultPrevented;
    }

    sfAliasAdapters() {
      return {
        [OVERLAY_EVENTS_LEGACY.action]: LEGACY_DETAIL.action,
        [OVERLAY_EVENTS_LEGACY.edit]: LEGACY_DETAIL.edit,
      };
    }

    /** Every valid insertion place in document order; moving excludes its own subtree and no-op places. */
    dropTargets(moving) {
      const excluded = new Set();
      if (moving) {
        const stack = [moving];
        while (stack.length) {
          const id = stack.pop();
          excluded.add(id);
          for (const children of Object.values(this.byId.get(id)?.slots || {})) stack.push(...children);
        }
      }
      const places = [];
      if (this.iframe) this.view = this.frameMetrics();
      const source = moving ? this.byId.get(moving) : null;
      for (const { parent, slot, children } of this.groups()) {
        if (excluded.has(parent)) continue;
        const remaining = moving ? children.filter((id) => id !== moving) : children;
        for (let index = 0; index <= remaining.length; index += 1) {
          if (source && (source.parent ?? '') === parent && source.slot === slot && index === source.index) continue;
          const descriptor = { parent_id: parent, slot, index };
          if (!this.dropFilter(descriptor, moving ? { node_id: moving } : activeSortableSession())) continue;
          const rect = this.placeRect(parent, slot, index, remaining);
          if (rect) places.push({ descriptor, rect, label: format(this.messages.insertAt, { slot, index: index + 1 }) });
        }
      }
      return places;
    }

    // Every list of places, the outer ones first: a node's slots, and in framed
    // mode the top level (parent "", slot "default") before them.
    groups() {
      const groups = [];
      const top = this.nodes.filter((node) => node.flat && !node.parent).map((node) => node.id);
      if (top.length) groups.push({ parent: '', slot: 'default', children: top });
      for (const node of this.nodes) {
        for (const [slot, children] of Object.entries(node.slots)) groups.push({ parent: node.id, slot, children });
      }
      return groups;
    }

    placeRect(parentId, slot, index, children) {
      const before = this.nodeBox(children[index]);
      const box = before || this.nodeBox(children[index - 1]) || this.nodeBox(parentId);
      if (!box) return null;
      const y = before ? box.top : box.bottom;
      return { left: box.left, top: y - 1, width: box.width, height: 3 };
    }

    resolveDrop(x, y, moving) {
      if (!this.canvas) return null;
      const under = globalThis.document.elementsFromPoint(x, y).find((element) => this.canvas.contains(element));
      let id = under ? this.nodeAt(under) : null;
      const allowedPlaces = moving ? this.dropTargets(moving) : null;
      const allowed = (descriptor) => (moving
        ? allowedPlaces.some((place) => JSON.stringify(place.descriptor) === JSON.stringify(descriptor))
        : this.dropFilter(descriptor, activeSortableSession()));
      // Over the moving node or its subtree there is no target.
      if (moving) {
        for (let cursor = id; cursor; cursor = this.byId.get(cursor)?.parent) {
          if (cursor === moving) {
            this.showDropHint(null);
            return null;
          }
        }
      }
      while (id) {
        const node = this.byId.get(id);
        // An empty slot of the container under the pointer is a target too.
        for (const [slot, children] of Object.entries(node.slots)) {
          const remaining = moving ? children.filter((entry) => entry !== moving) : children;
          const descriptor = { parent_id: node.id, slot, index: 0 };
          if (remaining.length === 0 && allowed(descriptor)) {
            const rect = this.placeRect(node.id, slot, 0, remaining);
            this.showDropHint(rect);
            return { descriptor, rect, label: format(this.messages.insertAt, { slot, index: 1 }) };
          }
        }
        if (!node.parent) break;
        const element = this.element(id);
        const box = element.getBoundingClientRect();
        const siblings = this.byId.get(node.parent).slots[node.slot];
        const remaining = moving ? siblings.filter((entry) => entry !== moving) : siblings;
        const position = remaining.indexOf(id);
        if (position >= 0) {
          const index = y > box.top + box.height / 2 ? position + 1 : position;
          const descriptor = { parent_id: node.parent, slot: node.slot, index };
          if (allowed(descriptor)) {
            const rect = this.placeRect(node.parent, node.slot, index, remaining);
            this.showDropHint(rect);
            return { descriptor, rect, label: format(this.messages.insertAt, { slot: node.slot, index: index + 1 }) };
          }
        }
        id = node.parent;
      }
      this.showDropHint(null);
      return null;
    }

    showDropHint(rect) {
      if (!this.dropHint) {
        this.dropHint = globalThis.document.createElement('div');
        this.dropHint.className = 'sf-composition-overlay-drop';
        this.layer?.append(this.dropHint);
      }
      this.dropHint.hidden = !rect;
      if (!rect) return;
      Object.assign(this.dropHint.style, this.onLayer(rect));
    }

    // Dragging by the grip action: the block dims, one line shows where it lands,
    // the canvas scrolls near its edges, Escape cancels. The pointer is captured,
    // so a frame under it does not swallow the moves.
    onToolbarPointerDown(event) {
      const button = event.target instanceof globalThis.Element ? event.target.closest('button[data-action]') : null;
      const action = button ? this.actions.find((entry) => entry.id === button.dataset.action) : null;
      const node = this.selectedId ? this.byId.get(this.selectedId) : null;
      if (event.button !== 0 || action?.icon !== GRIP_ICON || action.disabled || !node || (!node.flat && !node.parent)) return;
      event.preventDefault();
      this.endGripDrag(false);
      button.focus({ preventScroll: true });
      button.setPointerCapture?.(event.pointerId);
      const connection = new AbortController();
      const options = { signal: connection.signal };
      const drag = { id: this.selectedId, startY: event.clientY, y: event.clientY, started: false, request: 0, place: null, dim: null, connection };
      this.gripDrag = drag;
      globalThis.addEventListener('pointermove', (moveEvent) => {
        drag.y = moveEvent.clientY;
        if (!drag.started && Math.abs(drag.y - drag.startY) > DRAG_START) this.beginGripDrag(drag);
      }, options);
      globalThis.addEventListener('pointerup', () => this.endGripDrag(true), options);
      globalThis.addEventListener('pointercancel', () => this.endGripDrag(false), options);
      globalThis.addEventListener('keydown', (keyEvent) => {
        if (keyEvent.key !== 'Escape') return;
        keyEvent.preventDefault();
        keyEvent.stopPropagation();
        this.endGripDrag(false);
      }, { ...options, capture: true });
    }

    beginGripDrag(drag) {
      drag.started = true;
      this.clearSeam();
      this.setHover(null);
      drag.dim = this.selectedElement()?.animate?.([{ opacity: 0.35 }], { duration: 1, fill: 'forwards' }) ?? null;
      const step = () => {
        const port = this.scrollPort();
        const by = drag.y < port.top + DRAG_EDGE ? -DRAG_STEP : drag.y > port.bottom - DRAG_EDGE ? DRAG_STEP : 0;
        if (by) (this.scroller || globalThis).scrollBy({ top: by, behavior: 'instant' });
        this.trackGripDrag(drag);
        drag.request = globalThis.requestAnimationFrame(step);
      };
      drag.request = globalThis.requestAnimationFrame(step);
      this.trackGripDrag(drag);
    }

    // The nearest place among the node's siblings; its own place is a place too,
    // where a drop changes nothing.
    trackGripDrag(drag) {
      const node = this.byId.get(drag.id);
      if (!node) return;
      if (this.iframe) this.view = this.frameMetrics();
      const parent = node.parent ?? '';
      const siblings = this.nodes.filter((entry) => entry.parent === node.parent && entry.slot === node.slot && entry.id !== drag.id).map((entry) => entry.id);
      let best = null;
      for (let index = 0; index <= siblings.length; index += 1) {
        const rect = this.placeRect(parent, node.slot, index, siblings);
        if (!rect) continue;
        const descriptor = { parent_id: parent, slot: node.slot, index };
        const own = index === node.index;
        if (!own && !this.dropFilter(descriptor, { node_id: drag.id })) continue;
        const distance = Math.abs(drag.y - rect.top);
        if (!best || distance < best.distance) best = { descriptor, rect, own, distance };
      }
      drag.place = best;
      this.showDropHint(best?.rect ?? null);
    }

    endGripDrag(drop) {
      const drag = this.gripDrag;
      if (!drag) return;
      this.gripDrag = null;
      drag.connection.abort();
      if (drag.request) globalThis.cancelAnimationFrame(drag.request);
      drag.dim?.cancel();
      this.showDropHint(null);
      if (drop && drag.started && drag.place && !drag.place.own) this.emit(OVERLAY_EVENTS.move, moveDetail(drag.id, drag.place.descriptor));
    }

    // Moving a canvas node: pointer via the selected label, keyboard via the tree.
    onHandleDown(event) {
      if (this.iframe) return;
      if (event.button !== 0 || !this.selectedId || !this.byId.get(this.selectedId)?.parent) return;
      event.preventDefault();
      const moving = this.selectedId;
      this.pointerDrag?.abort();
      const pending = new AbortController();
      this.pointerDrag = pending;
      let place = null;
      globalThis.addEventListener('keydown', (keyEvent) => {
        if (keyEvent.key !== 'Escape') return;
        keyEvent.preventDefault();
        pending.abort();
        this.showDropHint(null);
      }, { signal: pending.signal, capture: true });
      globalThis.addEventListener('pointermove', (moveEvent) => {
        place = this.resolveDrop(moveEvent.clientX, moveEvent.clientY, moving);
      }, { signal: pending.signal });
      globalThis.addEventListener('pointerup', () => {
        pending.abort();
        this.showDropHint(null);
        if (place) this.emit(OVERLAY_EVENTS.move, moveDetail(moving, place.descriptor));
      }, { signal: pending.signal });
      globalThis.addEventListener('pointercancel', () => { pending.abort(); this.showDropHint(null); }, { signal: pending.signal });
    }

    startKeyboardMove() {
      const node = this.byId.get(this.selectedId);
      if (!node?.parent) return;
      const places = this.dropTargets(node.id);
      if (!places.length) return;
      this.moving = { node: node.id, places, index: 0 };
      this.live.textContent = format(this.messages.picked, { label: this.info(node).label });
      this.showKeyboardPlace();
    }

    showKeyboardPlace() {
      const place = this.moving.places[this.moving.index];
      this.showDropHint(place.rect);
      this.live.textContent = place.label;
    }

    onMoveKey(event) {
      const moving = this.moving;
      if (event.key === 'Escape' || event.key === 'Tab') {
        if (event.key === 'Escape') event.preventDefault();
        this.moving = null;
        this.showDropHint(null);
        this.live.textContent = this.messages.cancelled;
        return true;
      }
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        const place = moving.places[moving.index];
        this.moving = null;
        this.showDropHint(null);
        this.emit(OVERLAY_EVENTS.move, moveDetail(moving.node, place.descriptor));
        return true;
      }
      const step = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[event.key];
      if (step === undefined) return true;
      event.preventDefault();
      moving.index = Math.max(0, Math.min(moving.places.length - 1, moving.index + step));
      this.showKeyboardPlace();
      return true;
    }

    setInsertionTarget(target) {
      this._insertionTarget = target && typeof target.parent_id === 'string' && typeof target.slot === 'string' && Number.isSafeInteger(target.index)
        ? Object.freeze({ parent_id: target.parent_id, slot: target.slot, index: target.index }) : null;
      this.schedule();
      return this;
    }

    // Read once per measure: the seam and the offsets ask for every node.
    element(id) {
      if (!this.canvas || typeof id !== 'string') return null;
      let found = this.elementIndex?.get(id);
      if (!found || !found.isConnected) {
        this.elementIndex = new Map();
        for (const element of this.canvas.querySelectorAll('[data-sf-composition-id]')) {
          const key = element.getAttribute('data-sf-composition-id');
          if (!this.elementIndex.has(key)) this.elementIndex.set(key, element);
        }
        found = this.elementIndex.get(id);
      }
      return found ?? null;
    }

    info(node) {
      const described = this.describe(node) || {};
      const label = typeof described.label === 'string' && described.label.trim() ? described.label : node.id;
      const badges = Array.isArray(described.badges) ? described.badges.filter((badge) => typeof badge === 'string' && badge.trim()).slice(0, 4) : [];
      return { label, badges };
    }

    select(id, { focus = false, emit = true } = {}) {
      if (id !== null && !this.byId.has(id)) return this;
      if (this.editing && this.editing.id !== id) this.finishEdit(true);
      if (this.selectedId === id) return this;
      this.selectedId = id;
      this.renderTreeSelection();
      this.renderToolbar();
      // The frame and the toolbar arrive with the selection, in the same paint.
      this.settleGlide();
      this.observeGeometry();
      this.positionNow();
      if (id !== null) {
        const node = this.byId.get(id);
        const siblings = this.nodes.filter((entry) => entry.parent === node.parent && entry.slot === node.slot);
        const { label } = this.info(node);
        this.live.textContent = `${format(this.messages.selected, { label })}, ${format(this.messages.position, { index: siblings.indexOf(node) + 1, total: siblings.length })}`;
      }
      if (focus) this.tree.focus();
      if (emit) this.emit(OVERLAY_EVENTS.select, { ids: id === null ? [] : [id], id, node_id: id });
      return this;
    }

    setHover(id) {
      if (this.hoverId === id) return;
      this.hoverId = id;
      this.schedule();
    }

    nodeAt(target) {
      let element = target instanceof globalThis.Element ? target.closest('[data-sf-composition-id]') : null;
      while (element && this.canvas.contains(element)) {
        const id = element.getAttribute('data-sf-composition-id');
        if (this.byId.has(id)) return id;
        element = element.parentElement?.closest('[data-sf-composition-id]') || null;
      }
      return null;
    }

    onPointerMove(event) {
      this.setHover(this.nodeAt(event.target));
      this.trackPointer(event.clientX, event.clientY, false);
    }

    onPointerGone() {
      this.setHover(null);
      this.leaveSeam();
    }

    // One place to add: the seam under the pointer, read once a frame while it moves.
    trackPointer(x, y, inFrame) {
      this.pointer = { x, y, inFrame };
      if (this.pointerRequest) return;
      this.pointerRequest = globalThis.requestAnimationFrame(() => {
        this.pointerRequest = 0;
        this.updateSeam();
      });
    }

    updateSeam() {
      if (!this.pointer || !this.connection || this.editing || this.moving || this.gripDrag || this.pointerDrag || this.glide) return;
      if (this.iframe) this.view = this.frameMetrics();
      let { x, y } = this.pointer;
      if (this.pointer.inFrame) {
        if (!this.view) return;
        ({ left: x, top: y } = frameRectToHost({ x, y, width: 0, height: 0 }, this.view));
      }
      const seam = this.seamAt(x, y);
      if (!seam) {
        this.leaveSeam();
        return;
      }
      this.holdSeam();
      if (this.seam && seam.parent === this.seam.parent && seam.slot === this.seam.slot && seam.index === this.seam.index) return;
      this.seam = seam;
      this.positionInsertions();
    }

    /** The place whose seam lies within reach of a point on the host page; the outer lists win. */
    seamAt(x, y) {
      for (const { parent, slot, children } of this.groups()) {
        for (let index = 0; index <= children.length; index += 1) {
          const line = this.seamLine(parent, children, index);
          if (!line || x < line.left || x > line.left + line.width || Math.abs(y - line.top) > SEAM_REACH) continue;
          if (this.placeAllowed({ parent_id: parent, slot, index })) return { parent, slot, index };
        }
      }
      return null;
    }

    // Halfway between two blocks that stack; nothing between two that stand side by side.
    seamLine(parent, children, index) {
      const before = this.nodeBox(children[index]);
      const after = this.nodeBox(children[index - 1]);
      if (before && after) {
        if (after.bottom > before.top + 1) return null;
        const left = Math.min(before.left, after.left);
        return { left, width: Math.max(before.right, after.right) - left, top: (after.bottom + before.top) / 2 };
      }
      if (before || after) return { left: (before || after).left, width: (before || after).width, top: before ? before.top : after.bottom };
      const box = children.length ? null : this.nodeBox(parent);
      return box ? { left: box.left, width: box.width, top: box.top + box.height / 2 } : null;
    }

    // A framed host's filter hides insertion places; on a Composition canvas it speaks
    // for drops, with the dragged item, and the Document has the last word on the rest.
    placeAllowed(place) {
      return !this.iframe || this.dropFilter(place, null);
    }

    holdSeam() {
      if (this.seamTimer) globalThis.clearTimeout(this.seamTimer);
      this.seamTimer = 0;
    }

    // A short delay, so the pointer can reach the button.
    leaveSeam() {
      if (!this.seam || this.seamTimer) return;
      this.seamTimer = globalThis.setTimeout(() => {
        this.seamTimer = 0;
        this.seam = null;
        this.positionInsertions();
      }, SEAM_LEAVE);
    }

    clearSeam() {
      this.holdSeam();
      if (!this.seam) return;
      this.seam = null;
      if (this.insertionLayer) this.positionInsertions();
    }

    onCanvasClick(event) {
      const id = this.nodeAt(event.target);
      if (!id) return;
      // In the editor a click selects; it never follows links or submits.
      event.preventDefault();
      event.stopPropagation();
      this.select(id);
    }

    // A host-mapped key: the selected node's action whose shortcut it is. An
    // unavailable action takes the key and does nothing.
    runShortcut(event) {
      if (!this.selectedId || event.isComposing) return false;
      const action = this.actions.find((entry) => entry.shortcut && shortcutMatches(entry.shortcut, event));
      if (!action) return false;
      event.preventDefault();
      if (!action.disabled) this.sendRenamed('action', { action: action.id, scope: 'entry', ids: [this.selectedId] });
      return true;
    }

    onTreeKey(event) {
      if (this.moving && this.onMoveKey(event)) return;
      if (this.runShortcut(event)) return;
      if (event.key === ' ' && this.selectedId && !this.iframe) {
        event.preventDefault();
        this.startKeyboardMove();
        return;
      }
      const index = this.nodes.findIndex((node) => node.id === this.selectedId);
      const current = this.nodes[index];
      let next = null;
      if (event.key === 'ArrowDown') next = this.nodes[Math.min(this.nodes.length - 1, index + 1)];
      else if (event.key === 'ArrowUp') next = this.nodes[Math.max(0, index - 1)];
      else if (event.key === 'Home') next = this.nodes[0];
      else if (event.key === 'End') next = this.nodes.at(-1);
      else if (event.key === 'ArrowLeft' && current?.parent) next = this.byId.get(current.parent);
      else if (event.key === 'ArrowRight' && current) next = this.nodes.find((node) => node.parent === current.id) || null;
      else if (event.key === 'Escape' && this.selectedId !== null && (!this.iframe || isTopOpenSurface(this))) {
        event.preventDefault();
        this.select(null);
        return;
      } else if (event.key === 'Enter' && this.iframe && current?.flat?.editable) {
        event.preventDefault();
        this.edit(current.id);
        return;
      } else if (event.key === 'Enter' && this.toolbar.querySelector('button:not(:disabled)')) {
        event.preventDefault();
        this.toolbar.querySelector('button:not(:disabled)').focus();
        return;
      } else return;
      event.preventDefault();
      if (next) this.select(next.id);
    }

    onToolbarKey(event) {
      const buttons = [...this.toolbar.querySelectorAll('button:not(:disabled)')];
      const index = buttons.indexOf(globalThis.document.activeElement);
      // Enter and Space press the button in focus; the other shortcuts work here too.
      if (event.key !== 'Enter' && event.key !== ' ' && this.runShortcut(event)) return;
      const along = this.hasAttribute('data-sf-overlay-side')
        ? { ArrowDown: 1, ArrowUp: -1 }[event.key]
        : { ArrowRight: 1, ArrowLeft: -1 }[event.key];
      if (event.key === 'Escape') {
        event.preventDefault();
        this.tree.focus();
      } else if (along) {
        event.preventDefault();
        const step = this.hasAttribute('data-sf-overlay-side') || globalThis.getComputedStyle(this).direction !== 'rtl' ? along : -along;
        buttons[(index + step + buttons.length) % buttons.length]?.focus();
      }
    }

    onToolbarClick(event) {
      const button = event.target instanceof globalThis.Element ? event.target.closest('button[data-action]') : null;
      if (!button || !this.selectedId) return;
      // The grip is pressed to drag; a click from the keyboard still reaches the host.
      if (event.detail > 0 && this.actions.find((entry) => entry.id === button.dataset.action)?.icon === GRIP_ICON) return;
      this.sendRenamed('action', { action: button.dataset.action, scope: 'entry', ids: [this.selectedId] });
    }

    onInsertionClick(event) {
      const button = event.target instanceof globalThis.Element ? event.target.closest('button[data-parent]') : null;
      if (!button) return;
      const target = { parent_id: button.dataset.parent, slot: button.dataset.slot, index: Number(button.dataset.index) };
      this.setInsertionTarget(target);
      this.positionInsertions();
      this.emit(OVERLAY_EVENTS.insert, { ...target, parent: target.parent_id });
    }

    renderTree() {
      if (!this.tree) return;
      this.tree.setAttribute('aria-label', this.getAttribute('label') || this.messages.tree);
      this.tree.replaceChildren(...this.nodes.map((node) => {
        const item = globalThis.document.createElement('div');
        const siblings = this.nodes.filter((entry) => entry.parent === node.parent && entry.slot === node.slot);
        const { label, badges } = this.info(node);
        item.id = `${this.id || 'sf-overlay'}-item-${node.id}`.replace(/[^A-Za-z0-9_-]/gu, '-');
        item.setAttribute('role', 'treeitem');
        item.setAttribute('aria-level', String(node.level));
        item.setAttribute('aria-setsize', String(siblings.length));
        item.setAttribute('aria-posinset', String(siblings.indexOf(node) + 1));
        item.setAttribute('aria-label', badges.length ? `${label} (${badges.join(', ')})` : label);
        item.dataset.nodeId = node.id;
        return item;
      }));
      this.renderTreeSelection();
    }

    renderTreeSelection() {
      let active = null;
      for (const item of this.tree?.children || []) {
        const selected = item.dataset.nodeId === this.selectedId;
        item.setAttribute('aria-selected', selected ? 'true' : 'false');
        if (selected) active = item.id;
      }
      if (active) this.tree.setAttribute('aria-activedescendant', active);
      else this.tree?.removeAttribute('aria-activedescendant');
    }

    // Buttons stay where they are: each is kept by its action's id, updated in
    // place, and an unavailable one dims, so focus and neighbours never move.
    renderToolbar() {
      if (!this.toolbar) return;
      this.toolbar.setAttribute('aria-label', this.messages.toolbar);
      const active = globalThis.document.activeElement;
      const focused = this.toolbar.contains(active) ? active : null;
      const previous = this.actionParts;
      this.actionParts = new Map();
      for (const action of this.actions) {
        const kept = previous.get(action.id);
        const parts = kept && Boolean(kept.action.icon) === Boolean(action.icon) ? kept : this.createAction(action);
        this.updateAction(parts, action);
        this.actionParts.set(action.id, parts);
      }
      const roots = [...this.actionParts.values()].map((parts) => parts.root);
      if (roots.length !== this.toolbar.children.length || roots.some((root, index) => root !== this.toolbar.children[index])) this.toolbar.replaceChildren(...roots);
      if (focused && (!focused.isConnected || focused.disabled)) (this.toolbar.querySelector('button:not(:disabled)') || this.tree)?.focus();
      if (!this.selectedId || this.actions.length === 0) this.toolbar.hidden = true;
    }

    // With an icon: sf-icon-button at size 1/2, its label the name, and sf-tooltip
    // holding the label and the shortcut. In the DOM from setActions on, so both
    // load before the first selection needs them.
    createAction(action) {
      const doc = globalThis.document;
      if (!action.icon) {
        const button = doc.createElement('button');
        button.type = 'button';
        button.className = 'sf-composition-overlay-action';
        button.dataset.action = action.id;
        return { root: button, button, action };
      }
      const root = doc.createElement('span');
      root.className = 'sf-composition-overlay-tool sf-tooltip-anchor';
      const button = doc.createElement('sf-button-icon');
      button.setAttribute('size', '1/2');
      button.setAttribute('appearance', 'ghost');
      button.setAttribute('scheme', 'on-surface-variant');
      button.setAttribute('data-action', action.id);
      button.setAttribute('data-tooltip', '');
      const tooltip = doc.createElement('sf-tooltip');
      tooltip.setAttribute('appearance', 'dark');
      tooltip.setAttribute('size', '1/2');
      tooltip.setAttribute('arrow', 'bottom-center');
      tooltip.hidden = true;
      root.append(button, tooltip);
      return { root, button, tooltip, action };
    }

    updateAction(parts, action) {
      const { root, button, tooltip } = parts;
      parts.action = action;
      if (action.tone) root.dataset.tone = action.tone;
      else delete root.dataset.tone;
      button.toggleAttribute('disabled', action.disabled === true);
      if (!action.icon) {
        if (button.textContent !== action.label) button.textContent = action.label;
        return;
      }
      button.setAttribute('icon', action.icon);
      button.setAttribute('aria-label', action.label);
      tooltip.setAttribute('text', action.shortcut ? `${action.label}  ${action.shortcut}` : action.label);
      root.toggleAttribute('data-sf-overlay-grip', action.icon === GRIP_ICON);
    }

    schedule() {
      if (this.frameRequest || !this.connection) return;
      this.frameRequest = globalThis.requestAnimationFrame(() => {
        this.frameRequest = 0;
        this.position();
      });
    }

    positionNow() {
      if (!this.connection) return;
      if (this.frameRequest) globalThis.cancelAnimationFrame(this.frameRequest);
      this.frameRequest = 0;
      this.position();
    }

    /** A node's box on the host page: its element's rect, or in framed mode its frame box mapped out of the frame. */
    nodeBox(id) {
      const node = typeof id === 'string' ? this.byId.get(id) : null;
      if (!node) return null;
      if (!node.flat) return this.element(id)?.getBoundingClientRect() ?? null;
      const view = this.view;
      if (!view || !this.frameDoc) return null;
      const { element, rect } = node.flat;
      if (element) {
        if (!element.isConnected || element.ownerDocument !== this.frameDoc) return null;
        const box = element.getBoundingClientRect();
        if (!box.width && !box.height) return null;
        return frameRectToHost({ x: box.left, y: box.top, width: box.width, height: box.height }, view);
      }
      return frameRectToHost({ x: rect.x - view.scrollX, y: rect.y - view.scrollY, width: rect.width, height: rect.height }, view);
    }

    place(frame, id) {
      const box = id ? this.nodeBox(id) : null;
      if (!box) {
        frame.hidden = true;
        return null;
      }
      frame.hidden = false;
      Object.assign(frame.style, this.onLayer(box));
      const label = frame.firstChild;
      if (label) {
        // The label is the move handle of a canvas whose host gives no grip.
        label.hidden = Boolean(this.iframe) || this.actions.some((action) => action.icon === GRIP_ICON);
        const { label: text, badges } = this.info(this.byId.get(id));
        label.textContent = badges.length ? `${text} · ${badges.join(' · ')}` : text;
      }
      return box;
    }

    /** A box on the host page as the left, top, width and height of a part on the layer. */
    onLayer(box) {
      const { left, top, scaleX, scaleY } = this.layerOrigin();
      const out = { left: `${(box.left - left) / scaleX}px`, top: `${(box.top - top) / scaleY}px` };
      if (box.width !== undefined) out.width = `${box.width / scaleX}px`;
      if (box.height !== undefined) out.height = `${box.height / scaleY}px`;
      return out;
    }

    /**
     * Where the parts live. In the scroller of the canvas they lie in its content
     * and travel with it: nothing listens to its scroll. Elsewhere they stay fixed
     * to the viewport and follow every scroll by script.
     */
    syncPlace() {
      const anchor = this.iframe || this.canvas;
      this.scroller = nearestScroller(anchor);
      const travels = this.scroller === nearestScroller(this);
      this.setAttribute('data-sf-overlay-place', travels ? 'content' : 'viewport');
      if (travels) {
        this.followConnection?.abort();
        this.followConnection = null;
      } else if (!this.followConnection) {
        this.followConnection = new AbortController();
        globalThis.addEventListener('scroll', () => this.schedule(), { signal: this.followConnection.signal, passive: true, capture: true });
      }
      return travels;
    }

    /** The scroller's port on the host page, and where its scrolled content starts. */
    scrollPort() {
      const scroller = this.scroller;
      const root = globalThis.document.documentElement;
      if (!scroller) return { left: 0, top: 0, right: root.clientWidth, bottom: globalThis.innerHeight, contentTop: -globalThis.scrollY };
      const box = scroller.getBoundingClientRect();
      const scale = scroller.offsetHeight > 0 && box.height > 0 ? box.height / scroller.offsetHeight : 1;
      const left = box.left + scroller.clientLeft * scale;
      const top = box.top + scroller.clientTop * scale;
      return { left, top, right: left + scroller.clientWidth * scale, bottom: top + scroller.clientHeight * scale, contentTop: top - scroller.scrollTop * scale };
    }

    position() {
      if (!this.canvas && !this.iframe) return;
      const travels = this.syncPlace();
      this.elementIndex = null;
      this.observeGeometry();
      if (this.glide) {
        this.glide.pending = true;
        return;
      }
      if (this.iframe) {
        this.view = this.frameMetrics();
        this.applyClip(this.view);
      }
      this.place(this.hoverFrame, this.hoverId && this.hoverId !== this.selectedId ? this.hoverId : null);
      const box = this.place(this.selectedFrame, this.selectedId);
      this.positionToolbar(box, travels);
      this.positionInsertions();
      this.rememberOffsets();
    }

    positionToolbar(box, travels) {
      const clip = this.view?.clip;
      const visible = Boolean(box) && (!this.iframe || Boolean(clip && box.right > clip.left && box.left < clip.right && box.bottom > clip.top && box.top < clip.bottom));
      // No toolbar without a drawn selection, e.g. while the host re-renders,
      // unless it holds keyboard focus.
      if (visible) this.toolbar.hidden = this.actions.length === 0;
      else if (!this.toolbar.contains(globalThis.document.activeElement)) this.toolbar.hidden = true;
      if (!visible || this.toolbar.hidden) return;
      const port = travels ? this.scrollPort() : this.followPort();
      // The side only where the room for it is; otherwise above, as the docs say.
      const wantsSide = this.getAttribute('placement') === 'side';
      this.toggleAttribute('data-sf-overlay-side', wantsSide);
      let bar = this.toolbar.getBoundingClientRect();
      const { scaleY } = this.layerOrigin();
      const gap = px(globalThis.getComputedStyle(this.toolbar).marginBlockEnd) * scaleY;
      const side = wantsSide && port.right - box.right >= bar.width + gap;
      if (wantsSide && !side) {
        this.toggleAttribute('data-sf-overlay-side', false);
        bar = this.toolbar.getBoundingClientRect();
      }
      this.toolbar.setAttribute('aria-orientation', side ? 'vertical' : 'horizontal');
      if (travels) this.placeRail(box, bar, gap, port, side);
      else this.placeFollowing(box, bar, gap, port, side);
    }

    /**
     * The toolbar in the scrolled content: right-aligned above the block, where it
     * may overlap the block above and never the selected one. A block too tall to
     * show with its toolbar gives the rail its whole height, so the sticky toolbar
     * stays on screen while the block is. With no room above a block that fits, it
     * stands under the block; inside the block only when neither is possible.
     */
    placeRail(box, bar, gap, port, side) {
      // A sticky inset counts from inside the scroller's padding; the toolbar pins to its edge.
      const padding = this.scroller ? px(globalThis.getComputedStyle(this.scroller).paddingBlockStart) : 0;
      Object.assign(this.toolbar.style, { left: '', top: `${gap / this.layerOrigin().scaleY - padding}px` });
      if (side) {
        Object.assign(this.rail.style, this.onLayer({ left: box.right + gap, top: box.top, width: bar.width, height: Math.max(box.height, bar.height) }));
        return;
      }
      const lift = bar.height + gap;
      const tall = box.height + lift > port.bottom - port.top;
      const room = box.top - port.contentTop >= lift;
      let top = box.top - lift;
      let height = tall ? box.height + lift : bar.height;
      if (!room && !tall) top = box.bottom + gap;
      else if (!room) {
        top = port.contentTop;
        height = box.bottom - port.contentTop;
      }
      const width = Math.max(box.width, bar.width);
      const rtl = globalThis.getComputedStyle(this).direction === 'rtl';
      let left = rtl ? Math.max(box.left, port.left) : Math.min(box.right, port.right) - width;
      left = Math.max(port.left, Math.min(left, port.right - width));
      Object.assign(this.rail.style, this.onLayer({ left, top, width, height }));
    }

    /** The visible part of the page a viewport-fixed toolbar stays in. */
    followPort() {
      const root = globalThis.document.documentElement;
      return this.view?.clip ?? { left: 0, top: 0, right: root.clientWidth, bottom: globalThis.innerHeight };
    }

    // Above the node, else below it, and always inside the visible part.
    placeFollowing(box, bar, gap, port, side) {
      const rtl = globalThis.getComputedStyle(this).direction === 'rtl';
      let top;
      let left;
      if (side) {
        top = Math.max(port.top, Math.min(box.top, port.bottom - bar.height));
        left = box.right + gap;
      } else {
        const above = box.top - bar.height - gap;
        top = above >= port.top ? above : box.bottom + gap;
        top = Math.max(port.top, Math.min(top, port.bottom - bar.height));
        left = rtl ? box.left : box.right - bar.width;
      }
      const root = globalThis.document.documentElement;
      left = Math.max(0, Math.min(left, root.clientWidth - bar.width));
      Object.assign(this.toolbar.style, this.onLayer({ left, top }));
    }

    // One place to add under the pointer. Besides it only what the host keeps marked
    // and, for the keyboard, a place after the selected node that shows when it
    // takes focus: nothing else is ever drawn on the selected block.
    positionInsertions() {
      if (this.iframe) this.view = this.frameMetrics();
      const points = [];
      const add = (parent, slot, index, shown) => {
        if (points.some((point) => point.parent === parent && point.slot === slot && point.index === index)) {
          if (shown) points.find((point) => point.parent === parent && point.slot === slot && point.index === index).shown = true;
          return;
        }
        points.push({ parent, slot, index, shown });
      };
      const target = this.insertionTarget;
      if (this.seam) add(this.seam.parent, this.seam.slot, this.seam.index, true);
      if (target) add(target.parent_id, target.slot, target.index, true);
      const selected = this.selectedId ? this.byId.get(this.selectedId) : null;
      if (selected) {
        const parent = selected.parent ?? (selected.flat ? '' : null);
        if (parent !== null && this.placeAllowed({ parent_id: parent, slot: selected.slot, index: selected.index + 1 })) add(parent, selected.slot, selected.index + 1, false);
        else if (parent === null) for (const [slot, children] of Object.entries(selected.slots)) add(selected.id, slot, children.length, false);
      }
      // Buttons are reused by key so keyboard focus and marks survive repositioning.
      const existing = new Map([...this.insertionLayer.children].map((button) => [button.dataset.key, button]));
      const keep = new Set();
      for (const point of points) {
        const group = this.groups().find((entry) => entry.parent === point.parent && entry.slot === point.slot);
        const line = this.seamLine(point.parent, group?.children ?? [], point.index);
        if (!line) continue;
        const key = `${point.parent}|${point.slot}|${point.index}`;
        keep.add(key);
        let button = existing.get(key);
        if (!button) {
          button = globalThis.document.createElement('button');
          button.type = 'button';
          button.className = 'sf-composition-overlay-insert';
          button.dataset.key = key;
          button.dataset.parent = point.parent;
          button.dataset.slot = point.slot;
          button.dataset.index = String(point.index);
          const mark = globalThis.document.createElement('span');
          mark.className = 'sf-composition-overlay-insert-mark';
          mark.setAttribute('aria-hidden', 'true');
          button.append(mark);
          this.insertionLayer.append(button);
        }
        const marked = Boolean(target && target.parent_id === point.parent && target.slot === point.slot && target.index === point.index);
        button.setAttribute('aria-pressed', marked ? 'true' : 'false');
        button.setAttribute('aria-label', format(this.messages.insertAt, { slot: point.slot, index: point.index + 1 }));
        button.toggleAttribute('data-sf-insert-shown', point.shown);
        Object.assign(button.style, this.onLayer(line));
      }
      for (const [key, button] of existing) if (!keep.has(key)) button.remove();
    }

    /** The frame's viewport on the host page and the part of it that is visible (clip). */
    frameMetrics() {
      const iframe = this.iframe;
      const win = this.frameDoc?.defaultView;
      if (!iframe?.isConnected || !win) return null;
      const rect = iframe.getBoundingClientRect();
      if (!rect.width && !rect.height) return null;
      const style = globalThis.getComputedStyle(iframe);
      const sides = (name, suffix = '') => ({ top: px(style[`${name}Top${suffix}`]), right: px(style[`${name}Right${suffix}`]), bottom: px(style[`${name}Bottom${suffix}`]), left: px(style[`${name}Left${suffix}`]) });
      const view = frameViewport({ rect, layout: { width: iframe.offsetWidth, height: iframe.offsetHeight }, border: sides('border', 'Width'), padding: sides('padding'), inner: { width: win.innerWidth, height: win.innerHeight }, scroll: { x: win.scrollX, y: win.scrollY } });
      let clip = { left: view.left, top: view.top, right: view.left + view.width, bottom: view.top + view.height };
      // Scrolling ancestors hide what lies outside them, and so does the window. In
      // the scroller's content its own edge clips the parts natively, whatever the scroll.
      const root = globalThis.document.documentElement;
      const travels = this.getAttribute('data-sf-overlay-place') === 'content';
      for (let element = iframe.parentElement; element && element !== root && element !== globalThis.document.body && !(travels && element === this.scroller); element = element.parentElement) {
        const own = globalThis.getComputedStyle(element);
        if (own.overflowX === 'visible' && own.overflowY === 'visible') continue;
        const box = element.getBoundingClientRect();
        const left = box.left + element.clientLeft;
        const top = box.top + element.clientTop;
        clip = intersect(clip, { left, top, right: left + element.clientWidth, bottom: top + element.clientHeight });
      }
      view.clip = travels ? clip : intersect(clip, { left: 0, top: 0, right: root.clientWidth, bottom: root.clientHeight });
      const inner = this.frameDoc.documentElement;
      view.scrolls = Boolean(inner) && (inner.scrollHeight > win.innerHeight + 1 || inner.scrollWidth > win.innerWidth + 1);
      return view;
    }

    /**
     * Where the layer's own box starts. Everything the overlay draws is
     * `position: fixed` and placed from page coordinates, which is right
     * while the viewport is the containing block. An ancestor with
     * `contain: layout` becomes that containing block instead -- the
     * Framework's own drawer gives it to [data-sf-drawer-container] -- and
     * every frame then sat the ancestor's corner away from its node (48 px
     * under an app bar: simai/ui-source#58, found by ui-mail). The layer is
     * `inset: 0` of the same containing block, so its corner is exactly that
     * error: zero on an ordinary page, the ancestor's corner inside one.
     */
    layerOrigin() {
      const box = this.layer?.getBoundingClientRect?.();
      if (!box) return { left: 0, top: 0, scaleX: 1, scaleY: 1 };
      // A scale on an ancestor of the layer: its px are not the page's.
      const scaleX = box.width > 0 && this.layer.offsetWidth > 0 ? box.width / this.layer.offsetWidth : 1;
      const scaleY = box.height > 0 && this.layer.offsetHeight > 0 ? box.height / this.layer.offsetHeight : 1;
      return { left: box.left, top: box.top, scaleX, scaleY };
    }

    // Parts of a frame that scrolls inside itself, or of one seen through the host's
    // scrollers from a fixed layer, are cut to what shows. In the scrolled content a
    // frame as tall as its document needs no cut, and its edges keep their seams whole.
    applyClip(view) {
      const clip = view?.clip ?? null;
      const travels = this.getAttribute('data-sf-overlay-place') === 'content';
      let value = '';
      if (travels && view && !view.scrolls) value = '';
      else if (!clip || clip.right <= clip.left || clip.bottom <= clip.top) value = 'inset(50%)';
      else {
        const layer = this.layer.getBoundingClientRect();
        const { scaleX, scaleY } = this.layerOrigin();
        value = `inset(${(clip.top - layer.top) / scaleY}px ${(layer.right - clip.right) / scaleX}px ${(layer.bottom - clip.bottom) / scaleY}px ${(clip.left - layer.left) / scaleX}px)`;
      }
      this.layer.style.clipPath = value;
      this.insertionLayer.style.clipPath = value;
    }

    // Where each node lies in its canvas, whatever the scroll: what a glide starts from.
    nodeOffset(id) {
      const node = this.byId.get(id);
      if (node?.flat) {
        const win = this.frameDoc?.defaultView;
        const { element, rect } = node.flat;
        if (!element) return rect ? { left: rect.x, top: rect.y } : null;
        if (!win || !element.isConnected) return null;
        const box = element.getBoundingClientRect();
        return box.width || box.height ? { left: box.left + win.scrollX, top: box.top + win.scrollY } : null;
      }
      const box = this.element(id)?.getBoundingClientRect();
      if (!box || !this.canvas) return null;
      const canvas = this.canvas.getBoundingClientRect();
      return { left: box.left - canvas.left, top: box.top - canvas.top };
    }

    rememberOffsets() {
      this.offsets = new Map();
      for (const node of this.nodes) {
        const offset = this.nodeOffset(node.id);
        if (offset) this.offsets.set(node.id, offset);
      }
    }

    /**
     * A new list whose nodes changed order, came or went: blocks glide from where
     * they were and the frame and toolbar travel with the selected one, on one clock.
     * The parts are placed for the end first, so a measure in between cannot see a
     * block in flight. Answers whether it placed them.
     */
    startGlide(before) {
      if (!this.connection || !before.size || this.editing || calm()) return false;
      if (this.iframe) this.view = this.frameMetrics();
      const after = new Map();
      for (const node of this.nodes) {
        const offset = this.nodeOffset(node.id);
        if (offset) after.set(node.id, offset);
      }
      const byTop = (map) => [...map.keys()].filter((id) => before.has(id) && after.has(id)).sort((a, b) => map.get(a).top - map.get(b).top);
      const order = byTop(before);
      if (!order.length) return false;
      const changed = before.size !== after.size || [...after.keys()].some((id) => !before.has(id)) || byTop(after).some((id, index) => id !== order[index]);
      if (!changed) return false;
      this.hoverId = null;
      this.clearSeam();
      this.positionNow();
      const scaleY = (this.view?.scaleY ?? 1) / this.layerOrigin().scaleY;
      const animations = [];
      const glide = (element, from) => {
        const animation = element?.animate?.([{ transform: `translateY(${from}px)` }, { transform: 'none' }], GLIDE);
        if (animation) animations.push(animation);
      };
      const carried = new Set();
      for (const node of this.nodes) {
        const element = this.nodeElement(node);
        if (!element) continue;
        if (node.parent && carried.has(node.parent)) {
          carried.add(node.id);
          continue;
        }
        const target = this.ownBox(element);
        if (!after.has(node.id)) continue;
        if (!before.has(node.id)) {
          const fade = target.animate?.([{ opacity: 0 }, { opacity: 1 }], GLIDE);
          if (fade) animations.push(fade);
          carried.add(node.id);
          continue;
        }
        const from = before.get(node.id).top - after.get(node.id).top;
        if (Math.abs(from) < 0.5) continue;
        glide(target, from);
        carried.add(node.id);
      }
      const selected = this.selectedId;
      if (selected && before.has(selected) && after.has(selected)) {
        const from = (before.get(selected).top - after.get(selected).top) * scaleY;
        if (Math.abs(from) >= 0.5) {
          glide(this.selectedFrame, from);
          glide(this.getAttribute('data-sf-overlay-place') === 'content' ? this.rail : this.toolbar, from);
        }
      }
      if (!animations.length) return true;
      const state = { animations, pending: false };
      this.glide = state;
      Promise.allSettled(animations.map((animation) => animation.finished)).then(() => {
        if (this.glide !== state) return;
        this.glide = null;
        if (state.pending) this.schedule();
      });
      return true;
    }

    settleGlide() {
      const state = this.glide;
      if (!state) return;
      this.glide = null;
      for (const animation of state.animations) animation.finish();
    }

    nodeElement(node) {
      return node.flat ? node.flat.element : this.element(node.id);
    }

    // The outermost box that holds this node's element and no other node's: the
    // whole block moves, not its inner box. The canvas's own DOM is not changed:
    // Web Animations write no attribute.
    ownBox(element) {
      const others = this.nodes.map((node) => this.nodeElement(node)).filter((other) => other && other !== element && !element.contains(other));
      let box = element;
      for (let parent = box.parentElement; parent && parent !== parent.ownerDocument.body && parent !== this.canvas; parent = parent.parentElement) {
        if (others.some((other) => parent.contains(other))) break;
        box = parent;
      }
      return box;
    }

    /** The innermost node under a pointer event in the frame: the smallest element or rect node that holds it. */
    frameNodeAt(event) {
      let best = null;
      let area = Infinity;
      const consider = (id, width, height) => {
        if (width * height < area) {
          best = id;
          area = width * height;
        }
      };
      for (let element = isElement(event.target) ? event.target : event.target?.parentElement; element; element = element.parentElement) {
        const id = this.elementIds.get(element);
        if (id === undefined || !this.byId.has(id)) continue;
        const box = element.getBoundingClientRect();
        consider(id, box.width, box.height);
      }
      const win = this.frameDoc?.defaultView;
      if (win && this.rectNodes.length && finite(event.clientX)) {
        const x = event.clientX + win.scrollX;
        const y = event.clientY + win.scrollY;
        for (const { id, flat: { rect } } of this.rectNodes) {
          if (x >= rect.x && x <= rect.x + rect.width && y >= rect.y && y <= rect.y + rect.height) consider(id, rect.width, rect.height);
        }
      }
      return best;
    }

    onFrameClick(event) {
      if (this.editing && this.editing.element.contains(event.target)) return;
      // In the editor a click selects; it never follows links or submits. A
      // click on no node goes back to no selection (the letter itself).
      event.preventDefault();
      const id = this.frameNodeAt(event);
      if (id) event.stopPropagation();
      this.select(id);
    }

    onFrameDoubleClick(event) {
      if (this.editing) return;
      const id = this.frameNodeAt(event);
      if (!id || !this.byId.get(id).flat?.editable) return;
      event.preventDefault();
      this.edit(id);
    }

    onFrameKey(event) {
      if (this.editing) {
        if (event.isComposing) return;
        if (event.key === 'Enter' || event.key === 'Escape') {
          event.preventDefault();
          event.stopPropagation();
          this.finishEdit(event.key === 'Enter');
        }
        return;
      }
      if (!event.defaultPrevented) this.onTreeKey(event);
    }

    /** Starts plain-string editing of an editable node inside the frame; returns whether it started. */
    edit(id) {
      const node = typeof id === 'string' ? this.byId.get(id) : null;
      const element = node?.flat?.editable ? node.flat.element : null;
      if (!element || !this.frameDoc || !element.isConnected || element.ownerDocument !== this.frameDoc) return false;
      if (this.editing?.id === id) return true;
      if (this.editing) this.finishEdit(true);
      const returnFocus = globalThis.document.activeElement === this.tree;
      this.select(id);
      const doc = element.ownerDocument;
      const attribute = element.getAttribute('contenteditable');
      element.setAttribute('contenteditable', 'plaintext-only');
      // Where plaintext-only is unknown, rich editing is narrowed to plain text by hand.
      const plain = element.contentEditable === 'plaintext-only';
      if (!plain) element.setAttribute('contenteditable', 'true');
      const connection = new AbortController();
      const options = { signal: connection.signal };
      element.addEventListener('blur', () => this.finishEdit(true), options);
      element.addEventListener('input', () => this.schedule(), options);
      element.addEventListener('beforeinput', (event) => {
        const type = event.inputType || '';
        if (type === 'insertParagraph' || type === 'insertLineBreak' || (!plain && type.startsWith('format'))) event.preventDefault();
      }, options);
      if (!plain) {
        element.addEventListener('paste', (event) => {
          event.preventDefault();
          doc.execCommand('insertText', false, (event.clipboardData?.getData('text/plain') || '').replace(/\s+/gu, ' '));
        }, options);
      }
      this.editing = { id, element, saved: element.cloneNode(true), previous: plainText(element), attribute, connection, returnFocus };
      holdOpenSurfaceMark(this, true);
      this.setAttribute('data-sf-overlay-editing', '');
      element.focus({ preventScroll: true });
      const selection = doc.defaultView?.getSelection();
      if (selection) {
        const range = doc.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      this.live.textContent = format(this.messages.editing, { label: this.info(node).label });
      this.schedule();
      return true;
    }

    /** Ends the inline edit: commit emits sf-editor-overlay-change, then sf-composition-overlay-change and -edit (cancelable) when the text changed; cancel restores it. */
    finishEdit(commit) {
      const editing = this.editing;
      if (!editing) return;
      this.editing = null;
      editing.connection.abort();
      holdOpenSurfaceMark(this, false);
      this.removeAttribute('data-sf-overlay-editing');
      const { element } = editing;
      if (editing.attribute === null) element.removeAttribute('contenteditable');
      else element.setAttribute('contenteditable', editing.attribute);
      const restore = () => {
        if (element.isConnected) element.replaceChildren(...editing.saved.childNodes);
      };
      const value = plainText(element);
      if (!commit) restore();
      else if (value !== editing.previous) {
        // The host refused the value: the letter shows what it showed before.
        if (!this.sendRenamed('edit', { id: editing.id, value, previous: editing.previous }, true)) restore();
      }
      if (editing.returnFocus && this.isConnected) this.tree.focus({ preventScroll: true });
      this.schedule();
    }
  }

  registry.define('sf-editor-overlay', SfCompositionOverlay);
  // The former tag sf-composition-overlay is a dated alias (a subclass, noted once).
  defineTagAliases(SfCompositionOverlay, 'sf-editor-overlay', { define: (name, Class) => registry.define(name, Class) });
  return SfCompositionOverlay;
}

export default { OVERLAY_EVENTS, OVERLAY_EVENTS_FORMER_TAG, OVERLAY_EVENTS_LEGACY, checkOverlayActions, checkOverlayNodes, defineCompositionOverlay, flatOverlayNodes, frameRectToHost, frameViewport, overlayNodes, shortcutMatches };
