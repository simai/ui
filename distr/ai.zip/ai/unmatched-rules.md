# Unmatched rules report

Generated at: 2026-02-12T07:37:13.982Z
Total unmatched rules: 26

| Rule | Regex | type | mode | js | css |
| --- | --- | --- | --- | --- | --- |
| `cl-accordion` | `/sf-code="accordion"/` | smart | smart | true | false |
| `cl-sfAccordion` | `/sf-code="sfAccordion"/` | smart | smart | true | false |
| `cl-ajax` | `/sf-code="ajax"/` | smart | smart | true | false |
| `cl-button` | `/sf-code="button"/` | smart | smart | true | false |
| `cl-buttons` | `/sf-code="buttons"/` | smart | smart | true | false |
| `cl-cards` | `/sf-code="cards"/` | smart | smart | true | false |
| `cl-debug` | `/sf-code="debug"/` | smart | smart | true | false |
| `cl-edit` | `/sf-code="edit"/` | smart | smart | true | false |
| `cl-list` | `/sf-code="list"/` | smart | smart | true | false |
| `cl-news` | `/sf-code="news"/` | smart | smart | true | false |
| `cl-pagination` | `/sf-code="pagination"/` | smart | smart | true | false |
| `cl-search` | `/sf-code="search"/` | smart | smart | true | false |
| `cl-select` | `/sf-code="select"/` | smart | smart | true | false |
| `cl-span` | `/sf-code="span"/` | smart | smart | true | false |
| `cl-table` | `/sf-code="table"/` | smart | smart | true | false |
| `cl-tabs` | `/sf-code="tabs"/` | smart | smart | true | false |
| `cl-text` | `/sf-code="text"/` | smart | smart | true | false |
| `cl-textarea` | `/sf-code="textarea"/` | smart | smart | true | false |
| `cl-tags` | `/sf-code="tags"/` | smart | smart | true | false |
| `cl-icons` | `/sf-code="icons"/` | smart | smart | true | false |
| `cl-inputs` | `/sf-code="inputs"/` | smart | smart | true | false |
| `cl-close` | `/sf-code="close"/` | smart | smart | true | false |
| `cl-contentDivider` | `/sf-code="contentDivider"/` | smart | smart | true | false |
| `fancybox` | `/data-fancybox/` | attribute | component | true | true |
| `hideShow` | `/sf-hide-show/` | component | - | true | false |
| `highlight` | `/(?:class\s*=\s*["'][^"']*language-[^"']*["']\|<pre\b[^>]*>\s*<code\b[^>]*>)/i` | component | - | true | true |
