/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "f8ed3557d92a"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_js_ComponentObserver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d7f974466839");
/* harmony import */ var _register_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("58661bec99a6");



class Emoji extends _core_js_ComponentObserver__WEBPACK_IMPORTED_MODULE_0__.ComponentObserver {
  static componentName = 'Emoji';
  html = null;

  constructor(props) {
    super(props);
    const {
      emoji = '🙂',
      name,
      label,
      title,
      size = '1',
      decorative = false,
      skin,
      fallback,
      utilities = {}
    } = this.params || {};
    const className = this.attrs.class || this.attrs.className;
    this.element = document.createElement('span');

    if (this.id) {
      this.element.id = this.id;
    } // No sf-emoji--skin-* class: a skin tone is a character (withSkin
    // below), and the class had no rule behind it in any version (content
    // study E2, 2026-11-16).


    this.element.classList.add('sf-emoji', `sf-emoji--size-${size}`);

    if (className) {
      this.element.classList.add(...`${className}`.split(' ').filter(Boolean));
    }

    Object.entries(this.attrs).filter(([attr]) => !['class', 'className'].includes(attr)).forEach(([attr, value]) => {
      if (value === undefined || value === null) {
        return;
      }

      this.element.setAttribute(attr, value);
    });
    const content = this.withSkin(this.resolveEmoji(name, emoji, fallback), skin);
    this.element.textContent = content;
    const hidden = decorative || this.element.getAttribute('aria-hidden') === 'true';
    const labelledBy = this.element.getAttribute('aria-labelledby');
    const accessibleLabel = this.element.getAttribute('aria-label') || label || title || content;

    if (hidden) {
      this.element.setAttribute('aria-hidden', 'true');
      this.element.removeAttribute('role');
      this.element.removeAttribute('aria-label');
      this.element.removeAttribute('aria-labelledby');
    } else {
      this.element.setAttribute('role', 'img');
      this.element.removeAttribute('aria-hidden');

      if (!labelledBy && accessibleLabel) {
        this.element.setAttribute('aria-label', `${accessibleLabel}`);
      }
    }

    if (title) {
      this.element.title = title;
    }

    this.applyUtilities(this.element, utilities.emoji ?? utilities);
    this.template = this.element;
  }

  applyUtilities(target, utilities) {
    if (!target || !utilities) {
      return;
    }

    const normalize = value => {
      if (Array.isArray(value)) return value;
      if (typeof value === 'string') return value.split(' ');
      if (Array.isArray(value?.classes)) return value.classes;
      if (typeof value?.classes === 'string') return value.classes.split(' ');
      if (Array.isArray(value?.emoji)) return value.emoji;
      if (typeof value?.emoji === 'string') return value.emoji.split(' ');
      return [];
    };

    normalize(utilities).filter(Boolean).forEach(cls => target.classList.add(cls));
  }

  init() {} // A skin tone is a character, not a style: the Fitzpatrick modifier after an
  // emoji that takes one. The class sf-emoji--skin-* had no rule behind it, so
  // skin changed nothing. Written only after a base that takes a modifier --
  // after any other emoji the modifier shows as a separate colour swatch.


  withSkin(content, skin) {
    const modifier = SKIN_TONES[String(skin ?? '').toLowerCase()];
    if (!modifier || !content) return content;
    const [first, ...rest] = Array.from(content.replace(/[\u{1F3FB}-\u{1F3FF}]/gu, ''));
    if (!/\p{Emoji_Modifier_Base}/u.test(first)) return content;
    return [first, modifier, ...rest.filter(char => char !== '\uFE0F')].join('');
  }

  normalizeShortcode(value) {
    if (!value) return '';
    return `${value}`.toLowerCase().replace(/:/g, '').trim();
  }

  resolveEmoji(name, emoji, fallback) {
    const normalized = this.normalizeShortcode(name);

    if (normalized && SHORTCODES[normalized]) {
      return SHORTCODES[normalized];
    }

    return emoji || fallback || '';
  }

}

const SKIN_TONES = {
  1: '\u{1F3FB}',
  light: '\u{1F3FB}',
  2: '\u{1F3FC}',
  'medium-light': '\u{1F3FC}',
  3: '\u{1F3FD}',
  medium: '\u{1F3FD}',
  4: '\u{1F3FE}',
  'medium-dark': '\u{1F3FE}',
  5: '\u{1F3FF}',
  dark: '\u{1F3FF}'
};
const SHORTCODES = {
  smile: '😊',
  grin: '😁',
  laugh: '😂',
  wink: '😉',
  blush: '☺️',
  heart: '❤️',
  heart_eyes: '😍',
  kiss: '😘',
  thumbs_up: '👍',
  thumbs_down: '👎',
  ok: '👌',
  clap: '👏',
  pray: '🙏',
  muscle: '💪',
  eyes: '👀',
  rocket: '🚀',
  fire: '🔥',
  star: '⭐',
  sparkles: '✨',
  party: '🎉',
  tada: '🎉',
  check: '✅',
  cross: '❌',
  info: 'ℹ️',
  warning: '⚠️',
  question: '❓',
  lightbulb: '💡',
  sun: '☀️',
  moon: '🌙',
  cloud: '☁️',
  rain: '🌧️',
  snow: '❄️',
  lightning: '⚡',
  coffee: '☕',
  beer: '🍺',
  wine: '🍷',
  pizza: '🍕',
  burger: '🍔',
  cake: '🍰',
  gift: '🎁',
  phone: '📱',
  laptop: '💻',
  camera: '📷',
  music: '🎵',
  play: '▶️',
  pause: '⏸️',
  stop: '⏹️',
  record: '⏺️',
  forward: '⏭️',
  back: '⏮️',
  up: '⬆️',
  down: '⬇️',
  left: '⬅️',
  right: '➡️',
  plus: '➕',
  minus: '➖'
};
(0,_register_helper__WEBPACK_IMPORTED_MODULE_1__["default"])('Emoji', Emoji);

/***/ },

/***/ "fcc5f4951a5d"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emoji__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f8ed3557d92a");


/***/ },

/***/ "58661bec99a6"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   registerComponent: () => (/* binding */ registerComponent)
/* harmony export */ });
// Simple helper to register a component in one call.
// Usage inside component bundle:
//   import register from './register-helper';
//   register('Buttons', Buttons);
function registerComponent(name, cls) {
  if (!name || !cls) return;

  if (typeof window !== 'undefined' && typeof window.registerSfComponent === 'function') {
    window.registerSfComponent(name, cls);
    return;
  }

  if (typeof window !== 'undefined' && window.SF?.Loader?.registerComponent) {
    window.SF.Loader.registerComponent(name, cls);
    return;
  }

  if (typeof window !== 'undefined') {
    const pending = window.SF_PENDING_COMPONENTS = window.SF_PENDING_COMPONENTS || [];
    pending.push([name, cls]);
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (registerComponent);

/***/ },

/***/ "d7f974466839"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ComponentObserver: () => (/* binding */ ComponentObserver)
/* harmony export */ });
class ComponentObserver {
  // Components name themselves with a static field (static componentName =
  // 'Modal'), and the Loader writes the name on the prototype only when it
  // registers the class; the lifecycle events read the instance, so an
  // instance made before that announced itself as `undefined:render`. Not a
  // getter: the Loader assigns the prototype property, and an accessor
  // without a setter made that assignment throw.
  lifecycleName() {
    return this.componentName ?? this.constructor.componentName;
  }

  constructor(props) {
    this.props = props;
    this.id = props?.id;
    this.params = props?.param;
    this.attrs = props?.attrs || {};
    this.template = null;
    window.dispatchEvent(new CustomEvent(`${this.lifecycleName()}:beforeRender`, {
      detail: this
    }));
  }

  getUtilityMap() {
    return this.constructor.utilityMap || null;
  }

  extractUtilityClasses(values) {
    if (!Array.isArray(values)) {
      return [];
    }

    const classes = new Set();
    values.forEach(value => {
      if (typeof value !== 'string') {
        return;
      }

      const matches = value.match(/\(([^)]+)\)/g);

      if (!matches) {
        return;
      }

      matches.forEach(match => {
        const raw = match.slice(1, -1);
        raw.split(/\s+/).filter(Boolean).forEach(cls => {
          // Only explicit (.class) annotations are classes; the
          // parentheses in var(--token) are CSS values, not markup.
          if (cls.startsWith('.') && cls.length > 1) classes.add(cls.slice(1));
        });
      });
    });
    return Array.from(classes);
  }

  applyLayoutUtilities(target, selector) {
    if (!target || !selector) {
      return;
    }

    const map = this.getUtilityMap();

    if (!map || !map[selector]) {
      return;
    }

    const classes = this.extractUtilityClasses(map[selector]);
    classes.forEach(cls => target.classList.add(cls));
  }

  render() {
    this.html = this.template;

    if (typeof this.init === 'function') {
      this.init();
    }

    if (this.html) {
      window.dispatchEvent(new CustomEvent(`${this.lifecycleName()}:render`, {
        detail: this
      }));
    }

    return this.html;
  }

  destroy() {
    this.destroyInternal?.();
    this.props = null;
    this.id = null;
    this.params = null;
    this.template = null;

    if (this.html) {
      this.html.remove();
      this.html = null;
    }

    window.dispatchEvent(new CustomEvent(`${this.lifecycleName()}:destroy`, {
      detail: this
    }));
  }

  destroyInternal() {}

}

/***/ },

/***/ "b308fa8adbd8"
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/
/************************************************************************/
let __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _scss_index_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b308fa8adbd8");
/* harmony import */ var _js_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("fcc5f4951a5d");
/**
* SIMAI Framework
* Copyright 2008-2026 SIMAI Ltd
* http://simai.studio
* Read the license: http://framework.simai.studio/license/
* Documentation: http://framework.simai.studio/
* Support: http://simai.studio/support/
*
* EMOJI
*
* Entry point for importing components from this directory.
* Simplifies the import process in other parts of the project.
* Instead of importing individual files, all component can be imported through this file.
*/


})();

/******/ })()
;